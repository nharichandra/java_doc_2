package com.egen.loyaltyeventsproducer;

import com.egen.loyaltyeventsproducer.config.KafkaProducerConfig;
import com.egen.loyaltyeventsproducer.producer.LoyaltyRewardsProducer;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.support.serializer.JsonSerializer;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

@SpringBootApplication
public class LoyaltyEventsProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoyaltyEventsProducerApplication.class, args);
		/*LoyaltyRewardsProducer producer = new LoyaltyRewardsProducer();
		kafkaSender = getKafkaSender();
		//System.out.println("Kafka Props :"+kafkaProducerConfig.getBootstrapper());
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				producer.generateMessages(kafkaSender, TOPIC, 1);
			}
		}, 0, 4000);*/
	}

	/*private static final String TOPIC = "loyalty-rewards-info";
	private static final String BOOTSTRAP_SERVERS = "localhost:9092";
	private static final String CLIENT_ID_CONFIG = "rewards-generator";
	private static KafkaSender<String, JsonNode> kafkaSender;

	private static KafkaProducerConfig kafkaProducerConfig = new KafkaProducerConfig();

	public static reactor.kafka.sender.KafkaSender<String, JsonNode> getKafkaSender(){
		System.out.println(kafkaProducerConfig.getBootstrapper());
		Map<String, Object> props = new HashMap<>();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
		props.put(ProducerConfig.CLIENT_ID_CONFIG, CLIENT_ID_CONFIG);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

		SenderOptions<String, JsonNode> senderOptions = SenderOptions.create(props);
		return reactor.kafka.sender.KafkaSender.create(senderOptions);
	}*/


}
