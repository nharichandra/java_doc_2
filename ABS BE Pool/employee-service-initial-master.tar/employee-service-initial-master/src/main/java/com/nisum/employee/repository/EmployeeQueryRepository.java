package com.nisum.employee.repository;

import java.util.List;

import com.nisum.employee.dto.Employee;
import com.nisum.employee.entity.EmployeeDocument;

/**
 * Employee query repository.
 * 
 * @author Rjosula
 *
 */
public interface EmployeeQueryRepository {

    List<Employee> getAllEmployeesByDept(String departmentName);
    
    Employee updateEmployee(EmployeeDocument emplDoc);
}
