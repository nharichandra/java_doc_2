package com.customer.customerservice.exception;

public class CustomerNotFoundException extends RuntimeException {

    public CustomerNotFoundException(){
        super();
    }
    public CustomerNotFoundException(final String message){
        super(message);
    }
}
