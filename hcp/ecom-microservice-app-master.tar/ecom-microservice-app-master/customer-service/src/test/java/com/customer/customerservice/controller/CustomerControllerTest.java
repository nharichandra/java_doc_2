package com.customer.customerservice.controller;


import com.customer.customerservice.model.Address;
import com.customer.customerservice.model.Customer;
import com.customer.customerservice.service.CustomerService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(SpringRunner.class)
@WebMvcTest(value = CustomerController.class)
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
public class CustomerControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    CustomerService customerService;

    private SecureRandom random = new SecureRandom();

    Logger logger = LoggerFactory.getLogger(CustomerControllerTest.class);

    @Test
    public void createCustomerTest() throws Exception {
        Customer customer = getCustomerPOJO();
        String customerJsonData = this.mapToJson(customer);
        String URI = "/api/customer/createCustomer";

        Mockito.when(customerService.saveCustomer(Mockito.any(Customer.class))).thenReturn(customer);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(URI)
                                                .accept(MediaType.APPLICATION_JSON)
                                                .content(customerJsonData)
                                                .contentType(MediaType.APPLICATION_JSON)).andReturn();

        MockHttpServletResponse response = mvcResult.getResponse();
        logger.info(response.getContentAsString());

        Assertions.assertEquals(HttpStatus.CREATED.value(), response.getStatus());
        JSONAssert.assertEquals(customerJsonData,response.getContentAsString(),true);
    }

    @Test
    public void getCustomerByIdTest() throws Exception {
        Customer customer = getCustomerPOJO();
        String URI = "/api/customer/"+customer.getCustomerId();
        Mockito.when(customerService.getCustomerById(Mockito.anyString())).thenReturn(customer);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(URI)
                                                .accept(MediaType.APPLICATION_JSON)).andReturn();
        String expectedResponse = this.mapToJson(customer);
        String actualResponse = mvcResult.getResponse().getContentAsString();

        Assertions.assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());
        JSONAssert.assertEquals(expectedResponse,actualResponse,true);
    }

    @Test
    public void getAllCustomersTest() throws Exception {
        List<Customer> customerList = new ArrayList<>();
        Customer customer1 = getCustomerPOJO();
        Customer customer2 = getCustomerPOJO();
        customerList.add(customer1);
        customerList.add(customer2);

        Mockito.when(customerService.getAllCustomers()).thenReturn(customerList);
        String URI = "/api/customer/allCustomers";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(URI)
                .accept(MediaType.APPLICATION_JSON))
                .andReturn();
        String expectedResponse = this.mapToJson(customerList);
        String actualResponce = mvcResult.getResponse().getContentAsString();
        logger.info("Actual Response :"+actualResponce);

        Assertions.assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());

        Mockito.verify(customerService,Mockito.times(1)).getAllCustomers();

    }

    private String mapToJson(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    private Customer getCustomerPOJO(){
        String randomId = new BigInteger(130, random).toString(32);
        Customer customer = new Customer();
        customer.setCustomerId(randomId);
        customer.setCustomerName("Nagarjuna");
        customer.setEmail("abcd@gmail.com");
        customer.setAddresses(Arrays.asList(new Address("Krishna Nagar","Hyderabd","Telangana",500075L,"India","Home"),
                new Address("KPHB","Hyderabd","Telangana",500075L,"India","Home")));

        return customer;
    }
}
