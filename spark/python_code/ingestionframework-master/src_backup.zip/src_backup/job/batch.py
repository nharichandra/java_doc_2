from pyspark.sql import dataframe

# from src.config.config_objects import FileInput
# from src.publish.write_file import file_writer

from config.config_objects import FileInput
from publish.write_file import file_writer

def batch_job(jobs_all):
    for job in jobs_all.jobs:
        print("\n\n " + "* " * 30 + " Initiating Batch Job -- " + str(job.name)+ " "+  "* " * 30)

        dataframe_dict = {}

        # Identify type of input
        if job.fileInputs:
            for file_input in job.fileInputs:
                # file_input = FileInput(file_input)
                """
                Call read_file funcation and process 
                consume.read_file.file_reader
                """
                df = read_file(file_input)
                df.show(1, False)
                dataframe_dict[file_input.dataFrameName] = df


        if job.dbmsInputs:
            for dbms_input in job.dbmsInputs:
                # file_input = FileInput(file_input)
                df = read_table(dbms_input)
                #df.show(1, False)
                dataframe_dict[dbms_input.dataFrameName] = df


        if job.fileOutputs:
            for file_output in job.fileOutputs:
                file_writer(
                    dataframe_dict[file_output.dataFrameName],
                    file_output.format,
                    file_output.fileOutPath,
                    file_output.mode,
                    file_output.header,
                    file_output.delimiter,
                    file_output.numPartitions,
                    file_output.partitionBy,
                    file_output.addColumns
                )

        print("\n\n " + "* " * 30 + " Job Completed  -- " + str(job.name)+ " "+  "* " * 30)
        print("\n\n")


def read_file(file_input):
    # from src.consume.read_file import file_reader
    from consume.read_file import file_reader
    return file_reader(
        file_input.fileInPath,
        file_input.dataFormat,
        file_input.enforceSchemaFile,
        file_input.numPartitions
    )


def read_table(dbms_input):
    # from src.consume.read_table import table_reader
    from consume.read_table import table_reader
    return table_reader(
        dbms_input.driver,
        dbms_input.url,
        dbms_input.user,
        dbms_input.password,
        dbms_input.dbtable,
        dbms_input.numPartitions,
        dbms_input.partitionColumn,
        dbms_input.lowerBound,
        dbms_input.upperBound,
        dbms_input.queryTimeout,
        dbms_input.fetchsize,
        dbms_input.pushDownPredicate
    )














