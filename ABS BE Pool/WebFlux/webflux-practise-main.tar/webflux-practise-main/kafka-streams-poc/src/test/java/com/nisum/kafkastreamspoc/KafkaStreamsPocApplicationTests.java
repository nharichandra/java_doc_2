package com.nisum.kafkastreamspoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaStreamsPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
