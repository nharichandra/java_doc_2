package com.sample.javawithkafka;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.protocol.types.Field;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class ProducerSyncDemo {
    private static final Logger logger = LoggerFactory.getLogger(ProducerDemoCallback.class.getName());
    public static void main(String[] args)  {
        KafkaProducer<String, String> producer = null;
        long time = System.currentTimeMillis();
        int messageCount = 10;
        try
        {
            String bootstrapServers = "127.0.0.1:9092";
            // Initialize Producer configuration mandatory properties
            Properties properties = new Properties();
            properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
            properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

            producer =new KafkaProducer<String, String>(properties);


            for(long index=time; index<time+messageCount; index++)
            {
                ProducerRecord<String, String> producerRecord = new ProducerRecord<>("demo_topic_A", "Demo Message"+index);

                //Publishing messages to Broker using Synchronous Approach
                RecordMetadata recordMetadata = producer.send(producerRecord).get();
                logger.info("Index:"+index+"||Topic:"+recordMetadata.topic()+"||Partition:"+recordMetadata.partition()+"||Offset"+recordMetadata.offset());

            }

        }
        catch (Exception e)
        {
            logger.error("Exception occurred while publishing messages to Topic "+e);
        }
        finally {
            producer.flush();
            producer.close();;

        }

    }
}
