/**
 * 
 */
package com.nisum.employee.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

/**
 * Mongo DB configuration class.
 * 
 * @author Rjosula
 *
 */
@Configuration
@PropertySource(value = "classpath:app.properties")
public class EmployeeMongoConfig {

    @Autowired
    private AppProperties appProperties;

    /**
     * Mongo client instance to be utilised to create the mongo template.
     * 
     * @return mongoClient
     */
    @Bean
    public MongoClient mongoInstance() {
        ConnectionString connectionString = new ConnectionString(appProperties.getUri());
        MongoClientSettings mongoClientSettings = MongoClientSettings.builder().applyConnectionString(connectionString)
                .build();

        return MongoClients.create(mongoClientSettings);
    }

    /**
     * Mongo template.
     * 
     * @return mongoTemplate
     * @throws Exception throws an exception when db is not available
     */
    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
        return new MongoTemplate(mongoInstance(), "local");
    }
    
}
