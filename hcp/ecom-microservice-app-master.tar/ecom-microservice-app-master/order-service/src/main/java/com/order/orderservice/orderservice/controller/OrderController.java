package com.order.orderservice.orderservice.controller;

import com.order.orderservice.orderservice.FiegnClient.FiegnCustomerClient;
import com.order.orderservice.orderservice.FiegnClient.FiegnProductClient;
import com.order.orderservice.orderservice.exception.OrderNotFoundException;
import com.order.orderservice.orderservice.model.*;
import com.order.orderservice.orderservice.service.IOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@RestController
@RefreshScope
@RequestMapping("/api/order")
public class OrderController {

    @Autowired
    private IOrderService orderService;

    @Autowired
    private FiegnCustomerClient customerClient;

    @Autowired
    private FiegnProductClient productClient;



    @PostMapping("/create")
    public Order placeOrder(@RequestBody Order order){
        Customers customers = customerClient.getAllCustomers();

        if (customers.getCustomerList().size() == 0) {
            throw new OrderNotFoundException("No Customers Found. Can't Generate the Order");
        }
        List<Customer> customerList  = customers.getCustomerList();
        Collections.shuffle(customerList);
        Customer customer = customerList.get(0);

        Products products = productClient.getAllProducts();
        if (products.getProductList().size() == 0) {
            throw new OrderNotFoundException("No Products Found .Can't Generate the Order");
        }
        List<Product> productList = products.getProductList();
        Collections.shuffle(productList);
        Product product = productList.get(0);
        if(customer.getCustomerId().equals("0") || product.getProductId().equals("0")){
            throw new OrderNotFoundException("Service Gateway is down .Can't Generate the Order");
        }
        getCompleteOrderData(order,customer,product);
        return orderService.saveOrder(order);
    }

    @GetMapping("/{orderId}")
    public Order getOrderByID(@PathVariable("orderId") String orderId) {
        return orderService.getOrderById(orderId);
    }

    @GetMapping("/allOrders")
    public Orders getAllOrders(){
        List<Order> orderList = orderService.getAllOrders();
        return new Orders(orderList);
    }

    @PutMapping("/updateOrder/{orderId}")
    public Order updateOrder(@RequestBody Order newOrder, @PathVariable("orderId") String orderId){
        return orderService.updateOrder(newOrder,orderId);
    }


    private Order getCompleteOrderData(Order order, Customer customer, Product product) {
        order.setCustomerId(customer.getCustomerId());
        order.setOrderDate(LocalDateTime.now());
        order.setEmail(customer.getEmail());
        order.getLineItems().forEach(lineItem -> {
            lineItem.setProductName(product.getProductName());
            lineItem.setProductId(product.getProductId());
            lineItem.setPrice(product.getPrice());
        });
        ShipAddress shipAddress = new ShipAddress();

            for (Address address : customer.getAddresses()) {
                if (address.getAddressType().equals("home")) {
                    shipAddress.setAddressLine1(address.getAddressLine1());
                    shipAddress.setCity(address.getCity());
                    shipAddress.setState(address.getState());
                    shipAddress.setCountry(address.getCountry());
                    shipAddress.setName(customer.getCustomerName());
                    shipAddress.setZipcode(address.getZipcode());
                    shipAddress.setAddressType(address.getAddressType());
                }
            }

        order.setShipTo(shipAddress);
        return order;
    }
}
