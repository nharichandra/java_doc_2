package com.nisum.abs.loyaltyService.util;

import com.nisum.abs.loyaltyService.dto.LoyaltyDto;
import com.nisum.abs.loyaltyService.entity.Loyalty;
import org.springframework.beans.BeanUtils;

public class EntityToDtoConversionUtil {

    public static LoyaltyDto convertEntityToDto(Loyalty loyalty)
    {
        LoyaltyDto loyaltyDto = new LoyaltyDto();
        BeanUtils.copyProperties(loyalty, loyaltyDto);
        return loyaltyDto;
    }

    public static Loyalty convertDtoToEntity(LoyaltyDto loyaltyDto)
    {
        Loyalty loyalty = new Loyalty();
        BeanUtils.copyProperties(loyaltyDto, loyalty);
        return loyalty;
    }
}
