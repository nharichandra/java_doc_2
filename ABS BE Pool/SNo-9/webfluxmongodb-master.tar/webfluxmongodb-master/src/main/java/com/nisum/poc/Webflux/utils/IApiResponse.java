package com.nisum.poc.Webflux.utils;

public interface IApiResponse {
}
