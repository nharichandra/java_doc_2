package com.nisum.cloud.stream.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudStreamPublisherApplicationTests {

	@Test
	void contextLoads() {
	}

}
