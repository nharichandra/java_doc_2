package com.abs.userservice.controller;

public class UserDetailsController {
}
