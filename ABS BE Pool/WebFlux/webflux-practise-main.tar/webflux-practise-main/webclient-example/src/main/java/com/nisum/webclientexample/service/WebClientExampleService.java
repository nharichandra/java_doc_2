package com.nisum.webclientexample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.nisum.webclientexample.dto.Customer;
import com.nisum.webclientexample.dto.ProductDto;
import com.nisum.webclientexample.exception.CustomException;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class WebClientExampleService {

	@Autowired
	WebClient webClient;

	public Flux<ProductDto> findAll() {
		return webClient.get().uri("/products").retrieve().bodyToFlux(ProductDto.class);
	}

	public Mono<ProductDto> create(ProductDto prod) {
		return webClient.post().uri("/products").body(Mono.just(prod), ProductDto.class).retrieve()
				.bodyToMono(ProductDto.class);
		// .timeout(Duration.ofMillis(10_000));
	}

	public Flux<ProductDto> findById(String id) {
		return webClient.get().uri("/products/" + id).retrieve()
				.onStatus(HttpStatus::is4xxClientError,
						clientResponse -> Mono.error(new CustomException("4xx exception")))
				.onStatus(HttpStatus::is5xxServerError,
						clientResponse -> Mono.error(new CustomException("5xx exception")))
				.bodyToFlux(ProductDto.class);
	}

	public Flux<ProductDto> update(ProductDto prod) {
		return webClient.put().uri("/products/" + prod.getId()).body(Mono.just(prod), ProductDto.class).retrieve()
				.bodyToFlux(ProductDto.class);
	}

	public Flux<Void> delete(String id) {
		return webClient.delete().uri("/products/delete/" + id).retrieve().bodyToFlux(Void.class);
	}

	public Flux<Customer> findAllCustomers() {
		WebClient wc = WebClient.builder().baseUrl("http://localhost:8080/customers/")
				// .clientConnector(connector)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return wc.get().uri("stream/").retrieve().bodyToFlux(Customer.class);
	}

	public Flux<Customer> findNormalApiCustomers() {
		// TODO Auto-generated method stub
		WebClient wc = WebClient.builder().baseUrl("http://localhost:8080/customers/")
				// .clientConnector(connector)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return wc.get().retrieve().bodyToFlux(Customer.class);
	}

}
