package com.nisum.Webflux.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.nisum.Webflux.dto.StudentDTO;
import com.nisum.Webflux.model.Student;
import com.nisum.Webflux.service.StudentService;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class StudentHandler {

	@Autowired
	private StudentService studentService;

	public Mono<ServerResponse> getAllStudents(ServerRequest serverRequest) {
		return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(studentService.getAllStudentsRouting(),
				Student.class);
	}

	public Mono<ServerResponse> getById(ServerRequest request) {
		String id = request.pathVariable("getById");
		Mono<Student> student = request.bodyToMono(Student.class);
		return student
				.flatMap(st -> ServerResponse.ok().body(studentService.findById(Long.valueOf(id)), Student.class));
	}

	public Mono<ServerResponse> create(ServerRequest request) {
		Mono<StudentDTO> student = request.bodyToMono(StudentDTO.class);

		return student.flatMap(std -> ServerResponse.ok().body(studentService.createStudent(std), Student.class));

	}
}
