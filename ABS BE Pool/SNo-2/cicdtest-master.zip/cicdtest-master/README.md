CI CD concept apply on this simple project.

Created Stages:

1. Build
2. Test
3. Deploy