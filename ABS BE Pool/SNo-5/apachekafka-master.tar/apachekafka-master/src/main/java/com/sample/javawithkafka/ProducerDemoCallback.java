package com.sample.javawithkafka;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class ProducerDemoCallback {
    private static final Logger logger = LoggerFactory.getLogger(ProducerDemoCallback.class.getName());
    public static void main(String[] args) {

        KafkaProducer<String, String> producer = null;
        try
        {
            // Steps - create producer configs, create producer, send data / messages
            String bootstrapServers = "127.0.0.1:9092";
            // Initialize Producer configuration mandatory properties
            Properties properties = new Properties();
            properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
            properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

            producer = new KafkaProducer<String, String>(properties);

            ProducerRecord<String, String> record = new ProducerRecord<>("demo_topic_A","test message callback async");

            //Publishing messages to Broker using Asynchronous Approach
            producer.send(record, new Callback() {
                @Override
                public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                    if(e == null)
                    {
                        logger.info("Metadata from broker is ."+"\n"+
                                "Topic:"+recordMetadata.topic()+"\n"+
                                "Partition:"+recordMetadata.partition()+"\n"+
                                "Offset:"+recordMetadata.offset()+"\n"+
                                "Timestamp:"+recordMetadata.timestamp());
                    }
                    else {
                        logger.info("Exception occurred :"+e.getStackTrace());
                    }
                }
            });


        }
        catch (Exception e)
        {
            logger.error("Exception occurred:"+e);
        }
        finally {
            producer.flush();
            producer.close();
        }

    }
}