package com.nisum.task;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
