package com.nisum.poc.Webflux.mapper;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Student;
import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.model.AddressPayload;
import com.nisum.poc.Webflux.model.StudentPayload;
import com.nisum.poc.Webflux.model.SubjectPayload;
import org.mapstruct.factory.Mappers;

import java.util.List;

@org.mapstruct.Mapper(componentModel = "spring")
public interface AllMapper {
    AllMapper Instance = Mappers.getMapper(AllMapper.class);
    Address modelToEntity(AddressPayload addressPayload);
    AddressPayload entityToModel(Address address);
    List<AddressPayload> entitysToModels(List<Address> address);

    Student modelToEntity(StudentPayload studentPayload);
    StudentPayload entityToModel(Student student);
    Subject modelToEntity(SubjectPayload subjectPayload);
    SubjectPayload entityToModel(Subject subject);
}
