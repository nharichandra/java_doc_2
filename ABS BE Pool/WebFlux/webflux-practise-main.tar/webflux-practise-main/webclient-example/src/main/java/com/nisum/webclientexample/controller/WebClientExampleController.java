package com.nisum.webclientexample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.webclientexample.dto.Customer;
import com.nisum.webclientexample.dto.ProductDto;
import com.nisum.webclientexample.service.WebClientExampleService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/webclient-products")
public class WebClientExampleController {
	
	@Autowired
	private WebClientExampleService service;

	@GetMapping(produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<ProductDto> getProducts() {
		return service.findAll();
	}

	@GetMapping(value = "/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<ProductDto> getOneProduct(@PathVariable String id) {
		return service.findById(id);
	}

	@PostMapping(produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Mono<ProductDto> saveProduct(@RequestBody ProductDto productDto) {
		return service.create(productDto);
	}

	@PutMapping( produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<ProductDto> updateProduct(@RequestBody ProductDto productDto) {
		return service.update(productDto);
	}

	@DeleteMapping(value = "/delete/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<Void> deleteProduct(@PathVariable String id) {
		return service.delete(id);
	}

	@GetMapping(value="/customers",produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<Customer> getcustomers() {
		return service.findAllCustomers();
	}
	
	@GetMapping(value="/customers-normal",produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<Customer> getcustomersapi() {
		return service.findNormalApiCustomers();
	}
	
}
