package com.abs.userservice.request;

public class UserDetailsRequest {
}
