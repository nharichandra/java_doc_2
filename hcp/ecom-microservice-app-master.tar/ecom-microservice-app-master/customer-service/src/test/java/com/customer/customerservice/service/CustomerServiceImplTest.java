package com.customer.customerservice.service;

        import com.customer.customerservice.exception.CustomerNotFoundException;
        import com.customer.customerservice.model.Address;
        import com.customer.customerservice.model.Customer;
        import com.customer.customerservice.repository.CustomerRepository;
        import com.fasterxml.jackson.core.JsonProcessingException;
        import com.fasterxml.jackson.databind.ObjectMapper;
        import org.junit.Assert;
        import org.junit.Test;
        import org.junit.jupiter.api.Assertions;
        import org.junit.jupiter.api.BeforeAll;
        import org.junit.runner.RunWith;
        import org.mockito.Mockito;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.boot.test.context.SpringBootTest;
        import org.springframework.boot.test.mock.mockito.MockBean;
        import org.springframework.test.context.ActiveProfiles;
        import org.springframework.test.context.junit4.SpringRunner;

        import java.math.BigInteger;
        import java.security.SecureRandom;
        import java.util.ArrayList;
        import java.util.Arrays;
        import java.util.List;
        import java.util.Optional;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class CustomerServiceImplTest {

    @Autowired
    private  CustomerService customerService;

    @MockBean
    private CustomerRepository customerRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private SecureRandom random = new SecureRandom();


    @Test
    public void saveCustomerTest() throws JsonProcessingException {
        Customer customer = createCustomerData();
        System.out.println("Customer data :"+customer);
        Mockito.when(customerRepository.save(Mockito.any(Customer.class))).thenReturn(customer);
        Assertions.assertNotNull(customerRepository.save(customer));
        Assertions.assertEquals(customer, customerRepository.save(customer));
    }

    @Test
    public void getAllCustomersTest(){
        List<Customer> customerList = new ArrayList<>();
        Customer customer1 = createCustomerData();
        Customer customer2 = createCustomerData();
        customerList.add(customer1);
        customerList.add(customer2);

        Mockito.when(customerRepository.findAll()).thenReturn(customerList);
        Assertions.assertTrue(customerRepository.findAll().contains(customer1));
        Assertions.assertEquals(2, customerRepository.findAll().size());

    }

    @Test
    public void getCustomerByIdTest() throws CustomerNotFoundException
    {
        Optional<Customer> customer = Optional.of(createCustomerData());
        Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(customer);

        Assertions.assertTrue(customerRepository.findById(Mockito.anyString()).isPresent());

        Assertions.assertEquals(customer.get(),customerRepository.findById(Mockito.anyString()).get());
    }

    @Test(expected = CustomerNotFoundException.class)
    public void getCustomerByIdExceptionTest()
    {
        Mockito.when(customerRepository.findById(Mockito.anyString())).thenThrow(CustomerNotFoundException.class);
        customerService.getCustomerById("110");
    }

    private Customer createCustomerData() {
        String randomId = new BigInteger(130, random).toString(32);
        Customer customer = new Customer(randomId, "Nagarjun", "abcd@gmail.com",
                Arrays.asList(new Address("sahithiNiwas", "Hyderabad", "Telangana", 500075L, "India", "Home"),
                        new Address("Krishna Nagar", "Hyderabad", "Telangana", 500075L, "India", "Home")));
        return customer;
    }
}
