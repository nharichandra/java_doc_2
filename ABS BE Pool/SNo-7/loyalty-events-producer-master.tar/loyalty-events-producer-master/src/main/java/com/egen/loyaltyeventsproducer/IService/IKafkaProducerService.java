package com.egen.loyaltyeventsproducer.IService;

public interface IKafkaProducerService {
    public void generateKafkaMessages();
}
