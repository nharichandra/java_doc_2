package com.abs.userservice.service;

public class UserDetailsServiceImpl {
}
