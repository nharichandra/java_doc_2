package com.Kafka.demo.config;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class MessageStore {
    private List<String> allMessages = new ArrayList<>();
    public void addMessage(String message){
        allMessages.add(message);
    }
    public String getAllMessages(){
        return allMessages.toString();
    }
}
