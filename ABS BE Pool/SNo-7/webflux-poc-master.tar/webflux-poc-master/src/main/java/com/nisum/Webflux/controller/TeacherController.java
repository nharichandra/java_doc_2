package com.nisum.Webflux.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.Webflux.model.Teacher;
import com.nisum.Webflux.service.TeacherService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class TeacherController {
	
	@Autowired
	private TeacherService teacherService;
	
	@PostMapping("/create")
	Mono<Teacher> createTeacher(@RequestBody Teacher address) {
		return teacherService.createAddress(address);
	}

	@GetMapping("/getAll")
	private Flux<Teacher> getAllTeachers() {
		return teacherService.getAll();
	}

}
