package com.nisum.monofluxpractise;

import org.junit.jupiter.api.Test;

import reactor.core.publisher.Mono;

public class MonoFluxPractiseTest {
	
	@Test
	public void testMonoCreation() {
		Mono<String> test = Mono.just("test").log();
		test.subscribe(System.out::println);
		//test.subscribe(s->System.out.println(s.charAt(3)));
	}
	
	@Test
	public void testMonoError() {
		Mono<?> test = Mono.just("test").then(Mono.error(new RuntimeException("Test Exceptioin"))).log();
		test.subscribe(System.out::println);
		//test.subscribe(s->System.out.println(s.charAt(3)));
	}

}
