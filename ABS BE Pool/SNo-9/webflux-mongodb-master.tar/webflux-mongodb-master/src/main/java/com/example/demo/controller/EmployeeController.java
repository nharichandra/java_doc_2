package com.example.demo.controller;

import com.example.demo.exceptions.EmployeeNotFoundException;
import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/employee")
@Slf4j
public class EmployeeController {

    @Autowired
    private EmployeeServiceImpl employeeService;


    @PostMapping("/create/emp")
    @ResponseStatus(HttpStatus.CREATED)
    public void createEmp(@RequestBody Employee employee) {
      employeeService.createEmp(employee);
    }
    @GetMapping(value = { "/all"},produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public ResponseEntity<Flux<Employee>> getAllEmployees(){
        return ResponseEntity.ok().body(employeeService.findAll());
    }


    @GetMapping(value = { "/{id}"},produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public ResponseEntity<Mono<Employee>> getEmployeeById(@PathVariable("id") Integer id){

        return ResponseEntity.ok().body(employeeService.findEmployeeById(id));
    }


    @GetMapping(value = { "/findallempbyrole"})
    public Flux<Employee> getAllEmpbyRole(){
        return employeeService.findAllEmpBySal();
    }


    @PutMapping(value = { "/update"})
    public Mono<Employee> updateEmployee(@RequestBody Employee employee){
       return employeeService.updateEmployee(employee);
    }
    @PutMapping(value = { "/update/{id}"})
    public Mono<Employee> updateEmployeeById(@PathVariable("id") Integer id,
                                             @RequestParam("name") String name){
        if (name.isEmpty()) {
            throw new EmployeeNotFoundException("Name cant be Empty");
        }
            return employeeService.updateEmployeeById(id, name);
    }


    @PutMapping(value = { "/updateemployeebysal"})
    public Flux<Employee> updateEmployeeBySal(@RequestParam("sal") Integer sal,
                                              @RequestParam("role") String role){
      /*  if (StringUtils.isEmpty(sal)) {
            throw new EmployeeNotFoundException("Name cant be Empty");
        }*/
        log.info("in update employee by salary ");
        return employeeService.updateEmployeeBySal(sal, role);

    }



}
