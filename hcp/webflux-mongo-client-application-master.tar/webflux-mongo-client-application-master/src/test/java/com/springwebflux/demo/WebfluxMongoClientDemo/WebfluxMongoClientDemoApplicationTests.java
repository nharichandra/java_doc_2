package com.springwebflux.demo.WebfluxMongoClientDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxMongoClientDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
