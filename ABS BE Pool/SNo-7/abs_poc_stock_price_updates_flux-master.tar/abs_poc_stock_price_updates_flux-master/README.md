**JAVA REATCIVE PROGRAMMING POC SAMPLE : PRICE UPDATES USING PUBLISHER FLUX**

This POC project is used to get price updates using publisher type - Flux.

1.) Check the pom.xml to verify the required dependencies.

2.) Created src/main/java/org/abs/exercise/DefaultSubscriber.java to implement Reactive Stream API methods.
	Here, Added sysout staements to log the information.
	
3.) Created src/main/java/org/abs/exercise/StockPriceFluxPublisher.java to implement the logic of get and accumulate random value in a Reactive way.

4.) Created src/main/java/org/abs/exercise/StockPriceApplication.java to subscribe the publisher Flux [StockPriceFluxPublisher.java] and get price updates.

5.) Created src/main/java/org/abs/exercise/Util.java that returns dummy values using FAKER object.