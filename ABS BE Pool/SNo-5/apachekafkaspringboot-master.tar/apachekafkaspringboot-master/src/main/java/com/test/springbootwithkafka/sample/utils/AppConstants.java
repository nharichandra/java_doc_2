package com.test.springbootwithkafka.sample.utils;

public class AppConstants {

    public static final String
            TOPIC_NAME = "demo_topic_A";
    public static final String  GROUP_ID = "demo_group_id";
}
