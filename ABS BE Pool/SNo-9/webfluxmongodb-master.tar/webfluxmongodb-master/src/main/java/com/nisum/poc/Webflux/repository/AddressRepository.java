package com.nisum.poc.Webflux.repository;

import com.nisum.poc.Webflux.entity.Address;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface AddressRepository extends ReactiveMongoRepository<Address, String> {

    Flux<Address> findByStudentId(Long studentId);
}
