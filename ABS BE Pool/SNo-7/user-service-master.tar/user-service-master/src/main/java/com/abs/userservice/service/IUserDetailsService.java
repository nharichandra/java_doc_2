package com.abs.userservice.service;

public interface IUserDetailsService {
}
