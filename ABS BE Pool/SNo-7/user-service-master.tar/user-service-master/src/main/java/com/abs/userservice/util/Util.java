package com.abs.userservice.util;

public class Util {
}
