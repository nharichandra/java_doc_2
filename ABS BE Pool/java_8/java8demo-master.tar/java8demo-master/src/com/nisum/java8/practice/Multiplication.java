package com.nisum.java8.practice;

/**
 * 
 * 
 * @author Rjosula
 *
 */
public class Multiplication {
	
	/**
	 * Method to multiply two integer numbers.
	 * 
	 * @param a input a
	 * @param b input b
	 * @return multiplication product
	 */
	public static int multiply(int a, int b) {
		return a * b;
	}
}
