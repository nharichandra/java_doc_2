package com.sample.javawithkafka;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class ProducerDemoKeys {
    private static final Logger logger = LoggerFactory.getLogger(ProducerDemoKeys.class.getName());
    public static void main(String[] args) throws ExecutionException, InterruptedException {

        KafkaProducer<String, String> producer = null;
        try
        {
            // Steps - create producer configs, create producer, send data / messages
            String bootstrapServers = "127.0.0.1:9092";
            // Initialize Producer configuration mandatory properties
            Properties properties = new Properties();
            properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
            properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

            producer = new KafkaProducer<String, String>(properties);


            for(int i=0;i<10;i++)
            {
                String topic = "demo_topic_A";
                String value = "Demo Message";
                String key = "Id_"+Integer.toString(i);
                ProducerRecord<String, String> record = new ProducerRecord<>(topic, key, value);

                //Publishing messages with key to Broker using Asynchronous Approach
                producer.send(record, new Callback() {
                    @Override
                    public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                        if(e == null)
                        {
                            logger.info("Metadata from broker is ."+"\n"+
                                    "Topic:"+recordMetadata.topic()+"\n"+
                                    "Partition:"+recordMetadata.partition()+"\n"+
                                    "Offset:"+recordMetadata.offset()+"\n"+
                                    "Timestamp:"+recordMetadata.timestamp());
                        }
                        else {
                            logger.info("Exception is thrown :"+e.getStackTrace());
                        }
                    }
                }).get();

            }


        }
        catch (Exception e)
        {
            logger.error("Exception occurred during publishing messages:"+e);
        }
        finally {
            producer.flush();
            producer.close();
        }

    }
}