package com.nisum.Webflux.config;

import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
import static org.springframework.web.reactive.function.server.RequestPredicates.contentType;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.nisum.Webflux.handler.StudentHandler;

@Configuration
public class RouterConfig {

	@Bean
	RouterFunction<ServerResponse> routes(StudentHandler handler) {
		return route(GET("/students/getAll").and(accept(MediaType.APPLICATION_JSON)), handler::getAllStudents)
				.andRoute(GET("/students/getById/{id}").and(contentType(MediaType.APPLICATION_JSON)), handler::getById)
				.andRoute(POST("/students/create").and(accept(MediaType.APPLICATION_JSON)), handler::create);
	}

}
