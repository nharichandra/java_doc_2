package com.order.orderservice.orderservice.exception;

public class CustomerNotFoundException extends RuntimeException {

    public CustomerNotFoundException(){
        super();
    }
    public CustomerNotFoundException(final String message){
        super(message);
    }
}
