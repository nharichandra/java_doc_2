package com.nisum.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.employee.dto.Employee;
import com.nisum.employee.service.EmployeeService;

/**
 * Controller to handle the employee service calls.
 * 
 * @author Rjosula
 *
 */
@RestController
@RequestMapping("/api")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
    
    /**
     * Gets all the employees from employee document.
     * 
     * @return response entity of type
     */
    @GetMapping("/employees")
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(employeeService.fetchAllEmployees());
    }
    
    /**
     * Creates new employee into the employee db and return the created object.
     * 
     * @param employee employee request body
     * @return response body of employee object
     */
    @PostMapping("/employees")
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        return ResponseEntity.ok(employeeService.createEmployee(employee).get());
    }
    
    /**
     * Gets an employee based on the employee id input.
     * 
     * @param id employee id 
     * @return response employee
     */
    @GetMapping("/employees/byId")
    public ResponseEntity<Employee> getEmployeeById(@RequestParam String id) {
        return ResponseEntity.ok(employeeService
                .fetchEmployee(Long.valueOf(id)));
    }
    
    /**
     * Gets all employees who are all under the given department
     * @param department
     * @return response of list of employees
     */
    @GetMapping(value = "/employees/{department}")
    public ResponseEntity<List<Employee>> getAllEmployeesByDept
    (@PathVariable String department) {
        return ResponseEntity.ok(employeeService
                .fetchEmployeesByDepartment(department));
    }
    
    /**
     * 
     * @param employee employee dto as an input
     * @return employee dto
     */
    @PutMapping("/employees")
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee) {
        return ResponseEntity.ok(employeeService.updateEmployee(employee));
    } 
}
