package com.example.cicd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CicdTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
