package com.nisum.employee.util;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.nisum.employee.dto.Employee;
import com.nisum.employee.entity.EmployeeDocument;
import com.nisum.employee.service.EmployeeMapperService;

public interface EmpUtility {

    /**
     * Reusable method to provide employee dto based on employee document input.
     * 
     * @param empDocument employee document
     * @return employeeDto employee dto
     */
    public Function<EmployeeDocument, Employee> provideEmployee = (empDocument) -> {
        return EmployeeMapperService.MAPPER.employeeDtoToDocument(empDocument);
    };
    
    /**
     * Reusable static method to apply transformation for 
     * getting list of employee dto's based on employee documents.
     * 
     * @param emplDocs list of employee documents
     * @return list of employee dto's
     */
    public static List<Employee> provideEmployeeDto(List<EmployeeDocument> emplDocs) {
        return emplDocs.stream().map(empDoc -> EmpUtility.provideEmployee.apply(empDoc))
                .collect(Collectors.toList());
    }
}
