package com.test.springbootwithkafka.sample.service;

import com.test.springbootwithkafka.sample.utils.AppConstants;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {
    private static final Logger logger = LoggerFactory.getLogger(ProducerService.class.getName());

    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;

    public void sendMessage(String message)
    {
        logger.info("Sending message is:"+message);
        kafkaTemplate.send(AppConstants.TOPIC_NAME, message);
        logger.info("Message sent to Kafka Server/Broker...");
    }
}
