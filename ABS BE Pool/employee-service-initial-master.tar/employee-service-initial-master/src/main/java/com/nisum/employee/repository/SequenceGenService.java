package com.nisum.employee.repository;

import static org.springframework.data.mongodb.core.FindAndModifyOptions.options;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.nisum.employee.entity.DatabaseSequence;

/**
 * Custom sequence generator for generic collection based on collection name.
 * 
 * @author Rjosula
 *
 */
@Service
public class SequenceGenService {
    
    @Autowired
    private MongoOperations mongoOperations;
    
    /**
     * Gets the next sequence value for the primary key for employee documents.
     * @param sequenceName sequence name
     * @return sequence number
     */
    public long getNextValue(String sequenceName) {
        
        Query query = new Query(Criteria.where("id").is(sequenceName));
        
        Update update = new Update().inc("seq", 1);
        
        DatabaseSequence primarySequence = mongoOperations.findAndModify(
                query, update, options().returnNew(true).upsert(true),
                DatabaseSequence.class);
        return !Objects.isNull(primarySequence) ? primarySequence.getSeq() : 1;
    }
}
