package com.nisum.employee.service;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.nisum.employee.dto.Employee;
import com.nisum.employee.entity.EmployeeDocument;

/**
 * 
 * @author Rjosula
 *
 */
@Mapper
public interface EmployeeMapperService {
    
    EmployeeMapperService MAPPER = Mappers.getMapper(EmployeeMapperService.class);

    Employee employeeDtoToDocument(EmployeeDocument employeedocument);
    EmployeeDocument employeeDocumentToDto(Employee employee);
}
