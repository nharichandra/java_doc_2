package com.nisum.employee.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nisum.employee.entity.EmployeeDocument;

/**
 * Employee repository for employee operations.
 * 
 * @author Rjosula
 *
 */
@Repository
public interface EmployeeRepository extends CrudRepository<EmployeeDocument, Long> {
    
}
