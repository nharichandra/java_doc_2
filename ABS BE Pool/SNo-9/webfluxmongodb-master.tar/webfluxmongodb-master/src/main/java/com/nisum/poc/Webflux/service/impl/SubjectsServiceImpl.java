package com.nisum.poc.Webflux.service.impl;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.repository.SubjectRepository;
import com.nisum.poc.Webflux.service.ISubjectsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class SubjectsServiceImpl implements ISubjectsService {

    @Autowired
    SubjectRepository subjectRepository;
    @Override
    public Mono<Subject> createSuject(Subject subject) {
        return subjectRepository.save(subject);
    }

    @Override
    public Flux<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }
}
