package com.nisum.webclientexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebclientExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebclientExampleApplication.class, args);
	}

}
