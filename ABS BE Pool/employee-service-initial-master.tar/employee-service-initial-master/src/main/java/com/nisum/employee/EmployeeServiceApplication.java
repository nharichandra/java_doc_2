package com.nisum.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.nisum.employee.config.AppProperties;


@SpringBootApplication
@EnableConfigurationProperties(AppProperties.class)
//@ComponentScan(basePackageClasses = {Service.class, Component.class, Configuration.class})
public class EmployeeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeServiceApplication.class, args);
	}
}
