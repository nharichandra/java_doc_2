package com.customer.customerservice.controller;

import com.customer.customerservice.CustomerServiceApplication;
import com.customer.customerservice.exception.CustomerNotFoundException;
import com.customer.customerservice.exception.ExceptionResponce;
import com.customer.customerservice.model.Address;
import com.customer.customerservice.model.Customer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONException;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = CustomerServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class CustomerControllerIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate testRestTemplate;

    private HttpHeaders headers = new HttpHeaders();
    private SecureRandom random = new SecureRandom();

    Logger logger = LoggerFactory.getLogger(CustomerControllerIntegrationTest.class);

    @Test
    public void createCustomerITTest() throws Exception {
        Customer customer = getCustomerPOJO();
        String inputJson = this.mapToJson(customer);
        String URI = "/api/customer/createCustomer";

        HttpEntity<Customer> entity = new HttpEntity<Customer>(customer,headers);
        ResponseEntity<String> response = testRestTemplate.exchange(
                formURLWithPort(URI), HttpMethod.POST, entity, String.class);
        logger.info("Saved Response is : "+response.getBody());

        Assertions.assertEquals(HttpStatus.CREATED.value(), response.getStatusCode().value());
        JSONAssert.assertEquals(inputJson, response.getBody(),true);
    }

    @Test
    public void getCustomerByIdITTest() throws JSONException {
        Customer customer = getCustomerPOJO();
        String PostURI = "/api/customer/createCustomer";
        HttpEntity<Customer> entity = new HttpEntity<Customer>(customer,headers);
        ResponseEntity<String> PostResponse = testRestTemplate.exchange(
                formURLWithPort(PostURI), HttpMethod.POST, entity, String.class);
        logger.info("Saved Response is : "+PostResponse.getBody());

        String GETUri = "/api/customer/"+customer.getCustomerId();

        ResponseEntity<String> GetResponse = testRestTemplate.exchange(
                formURLWithPort(GETUri), HttpMethod.GET, entity, String.class);
        String responseJSONBody = GetResponse.getBody();

        Assertions.assertEquals(HttpStatus.OK.value(), GetResponse.getStatusCode().value());
        JSONAssert.assertEquals(PostResponse.getBody(),responseJSONBody,true);

    }

    @Test
    public void getCustomerByIdITExceptionTest(){
        Customer customer = getCustomerPOJO();
        String PostURI = "/api/customer/createCustomer";
        HttpEntity<Customer> entity = new HttpEntity<Customer>(customer,headers);
        ResponseEntity<String> PostResponse = testRestTemplate.exchange(
                formURLWithPort(PostURI), HttpMethod.POST, entity, String.class);
        logger.info("Saved Response is : "+PostResponse.getBody());
        String GETUri = "/api/customer/111";
        ResponseEntity<ExceptionResponce> getResponse = testRestTemplate.exchange(
                formURLWithPort(GETUri), HttpMethod.GET, entity, ExceptionResponce.class);
        Assertions.assertEquals(HttpStatus.NOT_FOUND.value(), getResponse.getStatusCode().value());
    }

    private String mapToJson(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    private Customer getCustomerPOJO(){
        String randomId = new BigInteger(130, random).toString(32);
        Customer customer = new Customer();
        customer.setCustomerId(randomId);
        customer.setCustomerName("DurgaRani");
        customer.setEmail("abcd@gmail.com");
        customer.setAddresses(Arrays.asList(new Address("Krishna Nagar","Hyderabd","Telangana",500075L,"India","Home"),
                new Address("KPHB","Hyderabd","Telangana",500075L,"India","Home")));

        return customer;
    }

    private String formURLWithPort(String URI){
        return "http://localhost:"+port+URI;
    }
}
