package com.nisum.abs.loyaltyService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoyaltyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
