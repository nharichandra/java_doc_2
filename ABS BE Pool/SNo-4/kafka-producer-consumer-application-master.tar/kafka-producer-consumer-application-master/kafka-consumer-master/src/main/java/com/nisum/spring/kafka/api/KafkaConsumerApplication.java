package com.nisum.spring.kafka.api;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.PartitionOffset;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class KafkaConsumerApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaConsumerApplication.class);
	List<String> messages = new ArrayList<>();

	User userFromTopic = null;

	@GetMapping("/consumeStringMessage")
	public List<String> consumeMsg() {
		return messages;
	}

	/*
	 * @GetMapping("/consumeJsonMessage") public User consumeJsonMessage() { return
	 * userFromTopic; }
	 */

	@KafkaListener(topics = "sample1", containerFactory = "kafkaListenerContainerFactory")
	public List<String> getMsgFromTopic(String data) {
		LOGGER.info(String.format("Event message received -> %s", data));
		messages.add(data);
		return messages;
	}

	// https://reflectoring.io/spring-boot-kafka/
	// https://hevodata.com/learn/spring-kafka-consumer/
	// https://memorynotfound.com/spring-kafka-adding-custom-header-kafka-message-example/
	@KafkaListener(topicPartitions = @TopicPartition(topic = "test",
			partitionOffsets = {
			@PartitionOffset(partition = "0", initialOffset = "0"),
			@PartitionOffset(partition = "1", initialOffset = "0")
			}),
			containerFactory = "kafkaListenerContainerFactory")
	public void listenToPartition(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
			@Header(KafkaHeaders.OFFSET) int offset) { 

		System.out.println("Received Message: " + message + " from partition: " + partition + " offset : " + offset);
	}

	/*
	 * @KafkaListener(groupId = "nisum-2", topics = "sample1", containerFactory =
	 * "userKafkaListenerContainerFactory") public User getJsonMsgFromTopic(User
	 * user) { userFromTopic = user; return userFromTopic; }
	 */

	public static void main(String[] args) {
		SpringApplication.run(KafkaConsumerApplication.class, args);
	}
}
