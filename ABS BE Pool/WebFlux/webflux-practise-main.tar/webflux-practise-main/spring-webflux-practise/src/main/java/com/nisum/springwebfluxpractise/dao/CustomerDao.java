package com.nisum.springwebfluxpractise.dao;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.stereotype.Component;

import com.nisum.springwebfluxpractise.dto.Customer;

import reactor.core.publisher.Flux;

@Component
public class CustomerDao {
	
	private static void sleepExc(int i) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Customer> getCustomers() {
		return IntStream.rangeClosed(1, 10).peek(CustomerDao::sleepExc).peek(i->System.out.println("normal "+i)).mapToObj(i -> new Customer(i, "Customer" + i)).collect(Collectors.toList());
	}
	
	public Flux<Customer> getCustomersFlux() {
		return Flux.range(1, 10).delayElements(Duration.ofSeconds(1)).doOnNext(i->System.out.println("flux "+i)).map(i-> new Customer(i,"CustomerStream"+i));
	}
}
