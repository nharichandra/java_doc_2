package com.nisum.kafkaexample;

import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nisum.kafkaexample.entity.Product;

@SpringBootApplication
//@EnableScheduling
@RestController
public class KafkaExampleApplication {

	@Autowired
	private KafkaTemplate<String, Object> template;
	
	Logger log = LoggerFactory.getLogger(KafkaExampleApplication.class);

	private String topic = "test-1-topic";
	
	public static void main(String[] args) {
		SpringApplication.run(KafkaExampleApplication.class, args);
	}

	
	@PostMapping("/produce")
	public String publishMessage(@RequestBody Product product) throws JsonProcessingException {
		ObjectMapper objectMapper=new ObjectMapper();
		String s=  objectMapper.writeValueAsString(product);
		log.info("produce message :: "+s);
		template.send(topic, s);
		return "Data published";
	}

}
