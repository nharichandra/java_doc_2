package com.nisum.poc.Webflux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
