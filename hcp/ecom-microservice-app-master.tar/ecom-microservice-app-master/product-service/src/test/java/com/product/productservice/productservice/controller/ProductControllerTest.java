package com.product.productservice.productservice.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.product.productservice.productservice.model.Product;
import com.product.productservice.productservice.service.ProductService;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.autoconfigure.RefreshAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ProductController.class)
@ImportAutoConfiguration(RefreshAutoConfiguration.class)
public class ProductControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    ProductService productService;

    private SecureRandom random = new SecureRandom();

    Logger logger = LoggerFactory.getLogger(ProductControllerTest.class);

    @Test
    public void saveProductTest() throws Exception {
        Product product = getProductPOJO();
        String productJsonData = this.mapToJson(product);
        String URI = "/api/product/saveProduct";

        Mockito.when(productService.saveProduct(Mockito.any(Product.class))).thenReturn(product);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(URI)
                                                .accept(MediaType.APPLICATION_JSON)
                                                .content(productJsonData)
                                                .contentType(MediaType.APPLICATION_JSON)).andReturn();

        MockHttpServletResponse response = mvcResult.getResponse();
        logger.info("Saved Product Responce :"+response.getContentAsString());

        Assertions.assertEquals(HttpStatus.OK.value(), response.getStatus());
        JSONAssert.assertEquals(productJsonData,response.getContentAsString(),true);
    }

    @Test
    public void getProductByIDTest() throws Exception {
        Product product = getProductPOJO();
        String URI = "/api/product/"+product.getProductId();
        Mockito.when(productService.getProductById(Mockito.anyString())).thenReturn(product);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(URI)
                                                .accept(MediaType.APPLICATION_JSON)).andReturn();
        String expectedResponse = this.mapToJson(product);
        String actualResponse = mvcResult.getResponse().getContentAsString();

        Assertions.assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());
        JSONAssert.assertEquals(expectedResponse,actualResponse,true);
    }

    @Test
    public void getAllProductsTest() throws Exception {
        List<Product> productList = new ArrayList<>();
        Product product1 = getProductPOJO();
        Product product2 = getProductPOJO();
        productList.add(product1);
        productList.add(product2);

        Mockito.when(productService.getAllProducts()).thenReturn(productList);
        String URI = "/api/product/allProducts";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(URI)
                                     .accept(MediaType.APPLICATION_JSON))
                                     .andReturn();
        String expectedResponse = this.mapToJson(productList);
        String actualResponce = mvcResult.getResponse().getContentAsString();
        logger.info("Actual Response :"+actualResponce);

        Assertions.assertEquals(HttpStatus.OK.value(), mvcResult.getResponse().getStatus());

    }

    private String mapToJson(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    private Product getProductPOJO(){
        String randomId = new BigInteger(130, random).toString(32);
        Product product = new Product();
        product.setProductId(randomId);
        product.setProductName("Apple Iphone SE");
        product.setProductDesc("Iphone SE with 128GB");
        product.setPrice(299.99);
        return product;
    }
}
