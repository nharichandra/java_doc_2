package com.springwebflux.demo.WebfluxMongoDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxMongoDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
