package com.nisum.poc.Webflux.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubjectPayload {

    private Integer id;
    private String subjectName;
    private Long studentId;

}
