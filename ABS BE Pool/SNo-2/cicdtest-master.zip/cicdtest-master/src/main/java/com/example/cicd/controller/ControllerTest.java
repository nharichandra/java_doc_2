package com.example.cicd.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.cicd.model.User;

@RestController
public class ControllerTest {
	
	@RequestMapping("/test")
	public String testMessage() {
		
		return "Hello CI/CD Test";
	}
	
	@RequestMapping("/test-2")
	public String testMessage2() {
		
		return "Hello CI/CD Test-2";
	}

	
	@RequestMapping("/AllUsers")
	public List<User> allUsers() {
		
		List<User> listOfUsers = new ArrayList<>();
		listOfUsers.add(new User(1,"Anil","Pune"));
		listOfUsers.add(new User(2,"Mukesh","Hydrabad"));
		listOfUsers.add(new User(3,"Tarun","Berlin"));
		listOfUsers.add(new User(4,"Tarun_1","London"));
		return listOfUsers;
	}
}
