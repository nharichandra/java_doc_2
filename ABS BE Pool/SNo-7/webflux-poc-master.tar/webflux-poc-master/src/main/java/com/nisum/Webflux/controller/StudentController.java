package com.nisum.Webflux.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.Webflux.dto.StudentDTO;
import com.nisum.Webflux.model.Address;
import com.nisum.Webflux.model.Student;
import com.nisum.Webflux.model.Subject;
import com.nisum.Webflux.service.StudentService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple3;

@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@PostMapping("/create")
	private Mono<Student> createStudent(@RequestBody StudentDTO student) {
		return studentService.createStudent(student);
	}

	@PutMapping("/update")
	private Mono<Student> updateStudent(@RequestBody StudentDTO student) {
		return studentService.createStudent(student);
	}

	@GetMapping("/getById/{studentId}")
	private Mono<Student> getStudentById(@PathVariable String studentId) {
		System.out.println("studentId="+studentId);
		return studentService.findById(Long.valueOf(studentId));
		//return new ResponseEntity<Mono<Student>>(student, student != null ? HttpStatus.OK : HttpStatus.NOT_FOUND);
	}

	@GetMapping("/getAll")
	private Flux<StudentDTO> getAllStudents() {
		return studentService.getAllStudents();
	}

	@GetMapping("/searchNames/{name}")
	private Flux<Student> getStudentsByName(@PathVariable String name) {
		return studentService.getStudentsByName(name);
	}

	@GetMapping("/searchNamesByOrder/{name}")
	public Flux<Student> searchStudents(@PathVariable String name) {
		return studentService.fetchStudents(name);
	}
	
	@GetMapping("/searchNamesWithZip/{studentId}")
	private Mono<Tuple3<Student, List<Address>, List<Subject>>> getStudentsByNames(@PathVariable String studentId) {
		return studentService.zipWith(Long.valueOf(studentId));
	}
	
	
	@GetMapping("/getMapResults")
	private Flux<String> getMap() {
		return studentService.transformMap();
	}

	@GetMapping("/getFlatMapResults")
	private Flux<String> getFlatMap() {
		return studentService.transformUsingFlatMap();
	}

	@GetMapping("/getMergeResults")
	private Flux<String> getMerge() {
		return studentService.combineUsingMerge();
	}

	@GetMapping("/getConcatResults")
	private Flux<String> getConcat() {
		return studentService.concat();
	}

	@GetMapping("/getZipResults")
	private Flux<String> getZip() {
		return studentService.combineWithZip();
	}

}
