package com.nisum.employee.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.nisum.employee.dto.Employee;

/**
 * @author Rjosula
 *
 */
public interface EmployeeService {

    /**
     * Creates employee.
     * 
     * @param employee employee input
     * @return optional employee
     */
    Optional<Employee> createEmployee(Employee employee);
    
    /**
     * Updates employee.
     * 
     * @param employee employee input
     * @return optional employee
     */
    Employee updateEmployee(Employee employee);
    
    /**
     * Fetching employee by id.
     * 
     * @param employeeId input employee id
     * @return optional of employee
     */
    Employee fetchEmployee(Long employeeId);
    
    /**
     * Fetch all employees by department id
     * @param departmentId department input
     * @return list of employees
     */
    List<Employee> fetchEmployeesByDepartment(String departmentId);
    
    /**
     * Fetch all employees.
     * @return optional list of employees
     */
    List<Employee> fetchAllEmployees();
    
    /**
     * Fetch all get all employees who does not updated their addresses. 
     * @return list of employees
     */
    List<Employee> fetchAllEmployeesDoesNotUpdatedAddresses();
    
    /**
     * Get all employees group by their departments.
     * 
     * @return map of department and list of employees
     */
    Map<String, List<Employee>> fetchEmployeeCollectionGroupByDepartment();
    
    /**
     * Get all employees for the given list of employee ids.
     * @param emplIds input list of ids
     * @return optional of list of employees
     */
    Optional<List<Employee>> fetchAllEmployeeForGivenIds(List<String> emplIds);
    
    /**
     * Fetch 2 maximum salaried employees.
     * 
     * @return optional list of employees
     */
    Optional<List<Employee>> fetch2MaxSalariedEmployees();
    
    /**
     * Fetch list of employees ordered by salaries.
     * 
     * @return optional list of employees
     */
    Optional<List<Employee>> fetchAllEmployeesOrderByAscSalaries();
}
