package com.nisum.livescorestream.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "livescore")
public class LiveScore {

	@Id
	private String id;
	private String match_id;
	private String match_desc;
	private String score;
	private String innings;
	private String commentary;

	public LiveScore() {
	}

	public LiveScore(String id, String match_id, String match_desc, String score, String innings, String commentary) {
		this.id = id;
		this.match_id = match_id;
		this.match_desc = match_desc;
		this.score = score;
		this.innings = innings;
		this.commentary = commentary;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMatch_id() {
		return match_id;
	}

	public void setMatch_id(String match_id) {
		this.match_id = match_id;
	}

	public String getMatch_desc() {
		return match_desc;
	}

	public void setMatch_desc(String match_desc) {
		this.match_desc = match_desc;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getInnings() {
		return innings;
	}

	public void setInnings(String innings) {
		this.innings = innings;
	}

	public String getCommentary() {
		return commentary;
	}

	public void setCommentary(String commentary) {
		this.commentary = commentary;
	}

}
