package com.nisum.poc.Webflux.utils;

public class ApiResponse implements IApiResponse{
    private Object object;
    private boolean status;
    private String message;

    public ApiResponse(Object object, boolean status, String message) {
        this.object = object;
        this.status = status;
        this.message = message;
    }


}
