package com.nisum.poc.Webflux.service;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.model.AddressPayload;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public interface IAddressService {
    Mono<Address> createAddress(AddressPayload addressPayload);

    Flux<Address> getAllAddress();
}
