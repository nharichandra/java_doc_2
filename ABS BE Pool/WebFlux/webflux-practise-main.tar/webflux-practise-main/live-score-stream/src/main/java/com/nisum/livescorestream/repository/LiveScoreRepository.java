package com.nisum.livescorestream.repository;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.data.mongodb.repository.Tailable;

import com.nisum.livescorestream.entity.LiveScore;

import reactor.core.publisher.Flux;

public interface LiveScoreRepository extends ReactiveMongoRepository<LiveScore, String> {

	@Tailable
	Flux<LiveScore> findWithTailableCursorBy();
	
}