package com.abs.userservice.repository;

public class UserDetailsRepository {
}
