package com.order.orderservice.orderservice.FiegnClient;

import com.order.orderservice.orderservice.model.Product;
import com.order.orderservice.orderservice.model.Products;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;

@FeignClient(value = "product-service", fallback = FiegnProductClientFallBack.class)
public interface FiegnProductClient {
    @GetMapping("/api/product/allProducts")
    public Products getAllProducts();
}

@Component
class FiegnProductClientFallBack implements FiegnProductClient {
    @Override
    public Products getAllProducts(){
        Products products = new Products();
        products.setProductList(Arrays.asList(new Product("0","Fall Back Product", "Fall Back Product Desc",0.0)));
        return products;
    }
}
