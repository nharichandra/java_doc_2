package com.nisum.poc.Webflux.utils;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ConstantUtils {
    public static final String SAVE_SUCCESSFULL = "Saved Successfully";
    public static final String SAVE_FAILED = "Save Failed";
}
