package com.nisum.Webflux.utils;

import java.util.Optional;

import reactor.core.publisher.Mono;

public class WebFluxUtils {
	
	 public static <T> Mono<Optional<T>> optional(Mono<T> in) {
	        return in.map(Optional::of).switchIfEmpty(Mono.just(Optional.empty()));
	    }
	 
		
}
