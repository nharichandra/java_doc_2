package com.nisum.poc.Webflux.controller;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.service.IAddressService;
import com.nisum.poc.Webflux.utils.IApiResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.Mockito.*;
@RunWith(SpringRunner.class)
@WebFluxTest()
class AddressControllerTest {
    @Mock
    IAddressService addressService;
    @Autowired
    private WebTestClient webTestClient;
    @MockBean
    AddressController addressController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateAddress() {
        Address address = new Address("123l","hyd","hyd","12342","home",1232l);
        //when(addressService.createAddress(address)).thenReturn(Mono.just(address));
        Mono<Address> addressMono =  webTestClient.post().uri("/saveaddress")
               .body(Mono.just(address),Address.class)
               .exchange()
               .expectStatus().isOk().returnResult(Address.class).getResponseBody().next();
        StepVerifier.create(addressMono)
                .expectSubscription()
                .expectNext(new Address("123l","hyd","hyd","12342","home",1232l))
                .verifyComplete();

       /* Mono<Address> result = addressController.createAddress(new Address(Long.valueOf(1), "address", "city", "pinCode", "addressType", Long.valueOf(1)));
        Assertions.assertEquals(null, result);*/
    }

    @Test
    void testGetAllAddress() {
        when(addressService.getAllAddress()).thenReturn(null);

        Flux<Address> result = addressController.getAllAddress();
        Assertions.assertEquals(null, result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme