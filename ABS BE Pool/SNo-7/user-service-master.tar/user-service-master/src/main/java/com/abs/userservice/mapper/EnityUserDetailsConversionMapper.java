package com.abs.userservice.mapper;

public class EnityUserDetailsConversionMapper {
}
