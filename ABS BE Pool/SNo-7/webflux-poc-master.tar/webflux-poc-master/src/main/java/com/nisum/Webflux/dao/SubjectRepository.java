package com.nisum.Webflux.dao;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import com.nisum.Webflux.model.Subject;

import reactor.core.publisher.Flux;

@Repository
public interface SubjectRepository extends ReactiveMongoRepository<Subject, Long>{

	Flux<Subject> findByStudentId(Long studentId);
}
