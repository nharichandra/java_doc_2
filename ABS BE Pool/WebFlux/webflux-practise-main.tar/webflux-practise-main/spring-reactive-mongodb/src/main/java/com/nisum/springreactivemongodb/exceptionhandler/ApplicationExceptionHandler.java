package com.nisum.springreactivemongodb.exceptionhandler;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.nisum.springreactivemongodb.exception.CustomException;

@RestControllerAdvice
public class ApplicationExceptionHandler {
	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<?> handleCustomException(CustomException customException){
		Map<String,String> errorMap = new HashMap<>();
		errorMap.put("error message", customException.getMessage());
		errorMap.put("status", HttpStatus.BAD_REQUEST.toString());
		return new ResponseEntity<>(errorMap, HttpStatus.BAD_REQUEST);
	}

}
