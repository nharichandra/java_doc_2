package com.nisum.springreactivemongodb.repository;

import org.springframework.data.domain.Range;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.nisum.springreactivemongodb.dto.ProductDto;
import com.nisum.springreactivemongodb.entity.Product;

import reactor.core.publisher.Flux;

public interface ProductRepository extends ReactiveMongoRepository<Product, String> {

	Flux<ProductDto> findByPriceBetween(Range<Double> priceRange);

//	@Tailable
//	Flux<Product> findWithTailableCursorBy();
}