package com.Kafka.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class MessageConsumer {
    @Autowired
    private MessageStore store;

    @KafkaListener(topics = "${app.topic.name}",groupId = "group1")
    public void readMessage(String message){
        store.addMessage(message);
    }

}
