package com.product.productservice.productservice.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.product.productservice.productservice.ProductServiceApplication;
import com.product.productservice.productservice.exception.ExceptionResponce;
import com.product.productservice.productservice.model.Product;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigInteger;
import java.security.SecureRandom;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ProductServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class ProductControllerIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate testRestTemplate;

    private HttpHeaders headers = new HttpHeaders();
    private SecureRandom random = new SecureRandom();

    Logger logger = LoggerFactory.getLogger(ProductControllerIntegrationTest.class);

    @Test
    public void saveProductITTest() throws Exception {
        Product product = getProductPOJO();
        String inputJson = this.mapToJson(product);
        String URI = "/api/product/saveProduct";

        HttpEntity<Product> entity = new HttpEntity<Product>(product,headers);
        ResponseEntity<String> response = testRestTemplate.exchange(
                formURLWithPort(URI), HttpMethod.POST, entity, String.class);
        logger.info("Saved Response is : "+response.getBody());

        Assertions.assertEquals(HttpStatus.OK.value(), response.getStatusCode().value());
        JSONAssert.assertEquals(inputJson, response.getBody(),true);
    }

    @Test
    public void getProductByIDITTest() throws Exception {
        Product product = getProductPOJO();
        String inputJson = this.mapToJson(product);
        String URI = "/api/product/saveProduct";

        HttpEntity<Product> entity = new HttpEntity<Product>(product,headers);
        ResponseEntity<String> response = testRestTemplate.exchange(
                formURLWithPort(URI), HttpMethod.POST, entity, String.class);
        logger.info("Saved Response is : "+response.getBody());

        String GetURI = "/api/product/"+product.getProductId();

        ResponseEntity<String> getResponse = testRestTemplate.exchange(
                formURLWithPort(GetURI), HttpMethod.GET, entity, String.class);
        String responseJSONBody = getResponse.getBody();

        Assertions.assertEquals(HttpStatus.OK.value(), getResponse.getStatusCode().value());
        JSONAssert.assertEquals(response.getBody(),responseJSONBody,true);

    }

    @Test
    public void getProductByIDITExceptionTest() throws JsonProcessingException {
        Product product = getProductPOJO();
        String inputJson = this.mapToJson(product);
        String URI = "/api/product/saveProduct";

        HttpEntity<Product> entity = new HttpEntity<Product>(product,headers);
        ResponseEntity<String> response = testRestTemplate.exchange(
                formURLWithPort(URI), HttpMethod.POST, entity, String.class);
        logger.info("Saved Response is : "+response.getBody());
        String GETUri = "/api/product/11";
        ResponseEntity<ExceptionResponce> getResponse = testRestTemplate.exchange(
                formURLWithPort(GETUri), HttpMethod.GET, entity, ExceptionResponce.class);
        Assertions.assertEquals(HttpStatus.NOT_FOUND.value(), getResponse.getStatusCode().value());
    }

    private String mapToJson(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    private Product getProductPOJO(){
        String randomId = new BigInteger(130, random).toString(32);
        Product product = new Product();
        product.setProductId(randomId);
        product.setProductName("Apple Iphone SE");
        product.setProductDesc("Iphone SE with 128GB");
        product.setPrice(299.99);
        return product;
    }

    private String formURLWithPort(String URI){
        return "http://localhost:"+port+URI;
    }
}
