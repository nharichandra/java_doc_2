package com.nisum.kafkastreamspoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaStreamsPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaStreamsPocApplication.class, args);
	}

}
