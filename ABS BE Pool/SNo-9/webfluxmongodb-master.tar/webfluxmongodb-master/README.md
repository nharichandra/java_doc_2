This Project is on webflux usage with MongoDB intigration with production like set up with profilings 
Added Exception Handling, and Mappers. 

used Webclient to call the service for every second using Scheduler.
