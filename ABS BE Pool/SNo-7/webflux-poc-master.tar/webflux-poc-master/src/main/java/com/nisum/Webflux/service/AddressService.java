package com.nisum.Webflux.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nisum.Webflux.dao.AddressRepository;
import com.nisum.Webflux.model.Address;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AddressService {

	@Autowired
	private AddressRepository addressRepository;

	public Mono<Address> createAddress(Address address) {
		return addressRepository.save(address);
	}

	public Flux<Address> getAll() {
		return addressRepository.findAll();
	}

	public Mono<Address> findById(Long id) {
		return addressRepository.findById(id);
	}

}
