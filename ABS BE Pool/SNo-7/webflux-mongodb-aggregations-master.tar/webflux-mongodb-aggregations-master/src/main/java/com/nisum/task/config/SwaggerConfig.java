package com.nisum.task.config;

//@Configuration
//@EnableSwagger2
//@OpenAPIDefinition(info = @Info(title = "Swagger Demo", version = "1.0", description = "Documentation APIs v1.0"))
public class SwaggerConfig {

//    @Bean
//    public Docket createRestApi() {
//        return new Docket(DocumentationType.SWAGGER_2)
//                .apiInfo(new ApiInfoBuilder()
//                        .description("My Reactive API")
//                        .title("My Domain object API")
//                        .version("1.0.0")
//                        .build())
//                .enable(true)
//                .select()
//                .apis(RequestHandlerSelectors.basePackage("com.nisum.task.controller"))
//                .paths(PathSelectors.any())
//                .build();
//    }
}
