package com.nisum.abs.loyaltyService.repository;

import com.nisum.abs.loyaltyService.entity.Loyalty;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoyaltyRepository extends ReactiveMongoRepository<Loyalty, String> {
}
