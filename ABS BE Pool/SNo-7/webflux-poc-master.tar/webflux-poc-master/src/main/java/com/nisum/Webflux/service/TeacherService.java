package com.nisum.Webflux.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nisum.Webflux.dao.TeacherRepository;
import com.nisum.Webflux.model.Teacher;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class TeacherService {

	@Autowired
	private TeacherRepository teacherRepository;

	public Mono<Teacher> createAddress(Teacher address) {
		return teacherRepository.save(address);
	}

	public Flux<Teacher> getAll() {
		return teacherRepository.findAll();
	}

	public Mono<Teacher> findById(Long id) {
		return teacherRepository.findById(id);
	}

}
