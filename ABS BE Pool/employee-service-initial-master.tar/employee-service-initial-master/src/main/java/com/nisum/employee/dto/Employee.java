/**
 * 
 */
package com.nisum.employee.dto;

import java.time.LocalDateTime;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Rjosula
 *
 */
@AllArgsConstructor
@Setter
@Getter
@ToString
public class Employee {

    private Long employeeId;
    private String employeeName;
    private List<Address> employeeAddress;
    private Long employeeSalary;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    
    @NotEmpty(message = "Should not be empty")
    private String departmentName;
    
    
    /*public Optional<Long> getEmployeeId() {
        return Optional.ofNullable(employeeId);
    }
    public Optional<String> getEmployeeName() {
        return Optional.ofNullable(employeeName);
    }
    public Optional<List<Address>> getEmployeeAddress() {
        return Optional.ofNullable(employeeAddress);
    }
    public Optional<Long> getEmployeeSalary() {
        return Optional.ofNullable(employeeSalary);
    }
    public Optional<LocalDateTime> getCreatedDate() {
        return Optional.ofNullable(createdDate);
    }
    public Optional<LocalDateTime> getModifiedDate() {
        return Optional.ofNullable(modifiedDate);
    }
    public Optional<String> getDepartmentName() {
        return Optional.ofNullable(departmentName);
    }*/
}
