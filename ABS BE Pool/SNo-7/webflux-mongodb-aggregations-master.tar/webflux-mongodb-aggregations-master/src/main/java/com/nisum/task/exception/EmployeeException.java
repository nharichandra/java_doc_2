package com.nisum.task.exception;

public class EmployeeException extends RuntimeException{

	
	public EmployeeException(String message) {
		super(message);
	}
}
