package com.order.orderservice.orderservice.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Document
public class Order {
    @Id
    private String orderId;
    private String orderNumber;
    private LocalDateTime orderDate;
    private String customerId;
    private String email;
    private List<LineItem> lineItems;
    private ShipAddress shipTo;

    public Order() {
    }

    public Order(String orderId, String orderNumber, LocalDateTime orderDate,
                 String customerId, String email, List<LineItem> lineItems, ShipAddress shipTo) {
        this.orderId = orderId;
        this.orderNumber = orderNumber;
        this.orderDate = orderDate;
        this.customerId = customerId;
        this.email = email;
        this.lineItems = lineItems;
        this.shipTo = shipTo;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<LineItem> getLineItems() {
        return lineItems;
    }

    public void setLineItems(List<LineItem> lineItems) {
        this.lineItems = lineItems;
    }

    public ShipAddress getShipTo() {
        return shipTo;
    }

    public void setShipTo(ShipAddress shipTo) {
        this.shipTo = shipTo;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId='" + orderId + '\'' +
                ", orderNumber='" + orderNumber + '\'' +
                ", orderDate=" + orderDate +
                ", customerId='" + customerId + '\'' +
                ", email='" + email + '\'' +
                ", lineItems=" + lineItems +
                ", shipTo=" + shipTo +
                '}';
    }
}
