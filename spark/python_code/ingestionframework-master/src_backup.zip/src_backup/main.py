import sys
import json


def main():
    system_arguments = sys.argv[1:]
    # print(system_arguments)

    # fileReader()

    config_file = ",".join([str(arg) for arg in system_arguments if ".json" in str(arg).lower()])
    property_file = ",".join([str(arg) for arg in system_arguments if ".prop" in str(arg).lower()])

    if not property_file:
        print("No Property File Used..")

    if not config_file:
        print("No Config File Found! ")
    else:
        read_config(config_file)


def read_config(config_file):
    with open(config_file) as json_file:
        config_json = json.load(json_file)

    from config.config_objects import Jobs
    #from src.config.config_objects import Jobs
    job_all = Jobs.from_json(json.dumps(config_json))

    print("\n\n"+ "*"*100)
    print('-' * 30 + ' Mode of Execution: ' + job_all.mode + ' ' + '-' * 30)
    for job in job_all.jobs:
        print('-' * 30 + ' Jobs identified: ' + str(job) + ' ' + '-' * 30)
    print("\n\n" + "*" * 100)

    if job_all.mode.lower() == "batch":
        from job.batch import batch_job
        #from src.job.batch import batch_job
        batch_job(job_all)

    elif job_all.mode.lower() == "stream":
        from job.direct_stream import direct_stream_job
        direct_stream_job(job_all)

    print('\n\n')
    print('-' * 30 + ' All Jobs processed sucessfully ' + '-' * 30)


# C:/tmp/pythonConfig/config_sample.json :/tmp/pythonConfig/spark.properties
# python src/job/src.py C:/tmp/pythonConfig/config_sample.json

# from ingestion framework dir
# spark-submit --jars ojdbc6.jar,databricks_delta.jar src/main.py C:/tmp/pythonConfig/config_sample.json
"""
/dbfs:FileStore/jars/3107c3a2_a06a_475b_ba60_7a8143348d25-ojdbc6.jar -- ojdbc6.jar
dbfs:/FileStore/jars/1d636af8_c57a_44bd_8326_c54015ede470-ojdbc6.jar -- ojdbc6.jar --
/FileStore/jars/fe48c5ea_3c2e_411a_9f67_57292209377a-databricks_delta.jar  -- databricks_delta.jar
dbfs:/FileStore/jars/fc2f0ee8_865f_4343_b8ba_f62694d39519-databricks_delta.jar -- databricks_delta.jar --
dbfs:/FileStore/jars/f2190b68_3b5a_4edc_81a0_d887e43e1f40-spark_xml_2_11_0_5_0-573f4.jar -- spark-xml_2.11-0.5.0.jar
/FileStore/tables/IngestionFramework/src/dependencies

/FileStore/tables/IngestionFramework/InputData/InputFiles/csv/abc.csv
/FileStore/tables/IngestionFramework/src/resources/config_databricks_file.json
"""

if __name__ == '__main__':
    main()
