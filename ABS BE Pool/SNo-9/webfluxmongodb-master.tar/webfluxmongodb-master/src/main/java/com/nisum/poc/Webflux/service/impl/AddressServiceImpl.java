package com.nisum.poc.Webflux.service.impl;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.exceptions.GlobalException;
import com.nisum.poc.Webflux.mapper.AllMapper;
import com.nisum.poc.Webflux.model.AddressPayload;
import com.nisum.poc.Webflux.repository.AddressRepository;
import com.nisum.poc.Webflux.service.IAddressService;
import com.nisum.poc.Webflux.utils.ConstantUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class AddressServiceImpl implements IAddressService {

    @Autowired
    AddressRepository addressRepository;

    @Autowired
    private AllMapper allMapper;
    @Override
    public Mono<Address> createAddress(AddressPayload addressPayload) {
        if (addressPayload.getStudentId() <=0) {
            throw new GlobalException(ConstantUtils.SAVE_FAILED);
        }
        return addressRepository.save(allMapper.modelToEntity(addressPayload));

    }

    @Override
    public Flux<Address> getAllAddress() {
        return addressRepository.findAll();
    }
}
