package com.nisum.Webflux.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.Webflux.model.Address;
import com.nisum.Webflux.service.AddressService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/address")
public class AddressController {

	@Autowired
	private AddressService addressService;

	@PostMapping("/create")
	Mono<Address> createAddress(@RequestBody Address address) {
		return addressService.createAddress(address);
	}

	@GetMapping("/getAll")
	private Flux<Address> getAllStudents() {
		return addressService.getAll();
	}
}
