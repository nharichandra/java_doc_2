package com.product.productservice.productservice.controller;

import com.product.productservice.productservice.exception.ProductNotFoundException;
import com.product.productservice.productservice.model.Product;
import com.product.productservice.productservice.model.Products;
import com.product.productservice.productservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RefreshScope
@RequestMapping("/api/product")
public class ProductController {

    @Autowired
    ProductService productService;

    @PostMapping("/saveProduct")
    public ResponseEntity<Product> saveProduct(@RequestBody Product product){
        Product savedProduct =  productService.saveProduct(product);
        if(savedProduct == null || savedProduct.getProductId() == null){
            throw new RuntimeException("Error While Saving the Product. Please check the Input");
        }
        return new ResponseEntity<Product>(savedProduct, HttpStatus.OK);
    }

    @GetMapping("/allProducts")
    public ResponseEntity<Products> getAllProducts() throws ProductNotFoundException {
        List<Product> productList = productService.getAllProducts();
        if (productList == null || productList.size() == 0){
            throw new ProductNotFoundException("No Products Found");
        }
        Products products =  new Products();
        products.setProductList(productList);
        return new ResponseEntity<Products>(products, HttpStatus.OK);
    }

    @GetMapping("/{productId}")
    public ResponseEntity<Product> getProductByID(@PathVariable("productId") String productId) throws ProductNotFoundException {
        Product product = productService.getProductById(productId);
        return new ResponseEntity<Product>(product, HttpStatus.OK);
    }
}
