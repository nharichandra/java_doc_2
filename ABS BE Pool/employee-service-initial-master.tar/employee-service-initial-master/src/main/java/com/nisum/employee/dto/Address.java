/**
 * 
 */
package com.nisum.employee.dto;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Address class contains employee address information.
 * 
 * @author Rjosula
 *
 */
@Setter
@AllArgsConstructor
@ToString
public class Address {

    private String streetName;
    private String roadNumber;
    private String localityBuilding;
    private String city;
    private long zipCode;
    public String getStreetName() {
        return streetName;
    }
    public String getRoadNumber() {
        return roadNumber;
    }
    public String getLocalityBuilding() {
        return localityBuilding;
    }
    public String getCity() {
        return city;
    }
    public long getZipCode() {
        return zipCode;
    }
}
