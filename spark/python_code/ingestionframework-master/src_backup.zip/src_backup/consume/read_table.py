from pyspark.sql import DataFrame

# from src.dependencies.schema_utilties import get_jdbc_options, get_jdbc_reader

from dependencies.db_audit import db_audit_query
from dependencies.schema_utilties import get_jdbc_options, get_jdbc_reader


def table_reader(
        driver,
        url,
        user,
        password,
        dbtable,
        dbIncremental,
        num_partitions,
        partition_column,
        lower_bound,
        upper_bound,
        query_timeout,
        fetch_size,
        predicate_pushdown
):
    if dbIncremental is not None:
        query, max_value = db_audit_query(
            url,
            user,
            password,
            driver,
            dbtable,
            dbIncremental
        )
    else:
        query = dbtable
        max_value = None

    options = get_jdbc_options(
        url,
        user,
        password,
        driver,
        query,
        num_partitions,
        partition_column,
        lower_bound,
        upper_bound,
        query_timeout,
        fetch_size,
        predicate_pushdown
    )

    reader = get_jdbc_reader(
        options
    )

    dataframe = reader.load()

    return dataframe, max_value
