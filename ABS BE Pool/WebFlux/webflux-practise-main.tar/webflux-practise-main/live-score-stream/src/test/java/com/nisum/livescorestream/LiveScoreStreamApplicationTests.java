package com.nisum.livescorestream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveScoreStreamApplicationTests {

	@Test
	void contextLoads() {
	}

}
