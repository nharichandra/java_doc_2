package com.abs.userservice.constants;

public class UserDetailsConstants {
}
