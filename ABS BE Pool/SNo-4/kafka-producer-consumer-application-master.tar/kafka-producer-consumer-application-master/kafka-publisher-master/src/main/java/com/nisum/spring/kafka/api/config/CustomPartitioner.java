package com.nisum.spring.kafka.api.config;

import java.util.Objects;

import org.apache.kafka.clients.producer.internals.DefaultPartitioner;
import org.apache.kafka.common.Cluster;

public class CustomPartitioner extends DefaultPartitioner{
	
	@Override
	  public int partition(String topic, Object key, byte[] keyBytes,
	  Object value, byte[] valueBytes,
	      Cluster cluster) {

	    String partitionKey = "";
	    if (Objects.nonNull(key)) {
	      String bookingKey = (String) key;
	      //Ignore bookingKey.getBookingDate()
	      keyBytes = partitionKey.getBytes();
	    }
	    return super.partition(topic, partitionKey, keyBytes, value,
	    valueBytes, cluster);
	  }

}
