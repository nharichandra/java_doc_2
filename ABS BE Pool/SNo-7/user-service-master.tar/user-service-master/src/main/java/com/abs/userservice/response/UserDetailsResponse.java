package com.abs.userservice.response;

public class UserDetailsResponse {
}
