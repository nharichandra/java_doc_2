package com.Kafka.demo.controller;

import com.Kafka.demo.config.MessageProducer;
import com.Kafka.demo.config.MessageStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MessageEmitterController {

    @Autowired
   private MessageProducer messageProducer;
    @Autowired
    private MessageStore store;

    @GetMapping("/send")
    public String sendMessage(@RequestParam("message") String message){
        String status =messageProducer.sendMessage(message);
        return status;
    }
    @GetMapping("/getData")
    public String getMessage(){

      return store.getAllMessages();




    }
}
