package com.order.orderservice.orderservice.model;

import java.util.List;

public class Customers {
    private List<Customer> customerList;

    public Customers(List<Customer> customerList) {
        this.customerList = customerList;
    }

    public Customers() {
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }
}
