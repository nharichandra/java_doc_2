package com.nisum.Webflux.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.Webflux.model.Subject;
import com.nisum.Webflux.service.SubjectService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/subject")
public class SubjectController {

	@Autowired
	private SubjectService subjectService;

	@PostMapping("/create")
	Mono<Subject> createSubject(@RequestBody Subject subject) {

		return subjectService.createSubject(subject);
	}

	@GetMapping("/getAll")
	private Flux<Subject> getAllSubjects() {
		return subjectService.getAll();
	}

}
