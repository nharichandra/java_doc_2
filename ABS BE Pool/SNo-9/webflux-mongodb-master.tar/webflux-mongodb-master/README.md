Spring WebFlux with Mongo DB Crud Operations with Aggragations functions.

using   
AggregationOperation,
Criteria criteria = new Criteria();
Query query = new Query(criteria);
