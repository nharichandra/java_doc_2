package com.nisum.springwebfluxpractise.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nisum.springwebfluxpractise.dao.CustomerDao;
import com.nisum.springwebfluxpractise.dto.Customer;

import reactor.core.publisher.Flux;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerDao customerDao;
	
	public List<Customer> getAllCustomers(){
		return customerDao.getCustomers();
	}
	
	public Flux<Customer> getAllCustomersFlux(){
		return customerDao.getCustomersFlux();
	}

}
