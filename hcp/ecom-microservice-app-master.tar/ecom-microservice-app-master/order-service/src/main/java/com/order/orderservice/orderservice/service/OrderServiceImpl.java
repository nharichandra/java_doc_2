package com.order.orderservice.orderservice.service;

import com.order.orderservice.orderservice.exception.OrderNotFoundException;
import com.order.orderservice.orderservice.model.Order;
import com.order.orderservice.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RefreshScope
public class OrderServiceImpl implements IOrderService{

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }

    @Override
    public Order getOrderById(String orderId) {
        Optional<Order> order =  orderRepository.findById(orderId);
        if(!order.isPresent()){
            throw new OrderNotFoundException("Order is Not Found with Given Order Id :"+orderId);
        }
        return order.get();
    }

    @Override
    public List<Order> getAllOrders() {
        List<Order> orderList = new ArrayList<>();
        orderList = orderRepository.findAll();
        if(orderList == null || orderList.size()==0){
            throw new OrderNotFoundException("No Orders Found Currently !!");
        }
        return orderList;
    }
    @Override
    public Order updateOrder(Order newOrder, String orderId) {
        return orderRepository.findById(orderId)
                .map(order -> {
                    order.setOrderNumber(newOrder.getOrderNumber());
                    order.setOrderDate(LocalDateTime.now());
                    return orderRepository.save(order);
                }).orElseThrow(() -> new OrderNotFoundException("Order Not Found with Given Id:"+orderId));
    }

    @Override
    public List<Order> getOrdersByDate(LocalDateTime dateTime) {
        return null;
    }
}
