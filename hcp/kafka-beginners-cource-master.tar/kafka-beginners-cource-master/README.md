
# Kafka Practice Sample Project

#Configuration and Important Commands to Run on CLI

Downlaod: 

 1) https://kafka.apache.org/downloads

 2) Scala 2.12  - kafka_2.12-2.4.1.tgz 


Configuration: 
 1.  Extract to Desired Location.
	(My Local Location: /Users/preddy/Documents/Kafka-Tutorial/Kafka_Learning_udemy/kafka_2.12-2.4.1/bin)

2. Use following commands to set the 
Class path to bash.profile file.
	-> cat ~/.bash_profile to check the existed class path settings
	-> nano ~/.bash_profile to update the class path settings
	-> Set the class path as: 
		export PATH ="$PATH:/Users/preddy/Documents/Kafka-Tutorial/Kafka_Learning_udemy/kafka_2.12-2.4.1/bin"
	-> Save and Exit
3. Check the Kafka installation by running the command :
        -> Kafka-Topics 
4. Create a folder “data >> zookeeper” in Kafka root directory.
5. Create a folder “data>>Kafka” in Kafka root directory.
6. Update “dataDir” value in zookeeper.properties with data>>zookeeper directory path.
	(Ex. dataDir=/Users/preddy/Documents/Kafka-Tutorial/Kafka_Learning_udemy/kafka_2.12-2.4.1/data/			zookeeper) to check the data 
7. Update “log.dir” in server.properties with data>>Kafka directory path.
	(Ex. log.dirs=/Users/preddy/Documents/Kafka-Tutorial/Kafka_Learning_udemy/kafka_2.12-2.4.1/data/			kafka)

CLI Commands:	
————————————
Start KAFKA: 

1. First we need to start zookeeper
	—> zookeeper-server-start config/zookeeper.properties (from root folder)
	—> binding to port 0.0.0.0/0.0.0.0:2181 (This is the confirmation for zookeeper start and 2181 is the default port for zookeeper)

2. Start Kafka Server now
	—> Kafka-server-start config/server.properties (from root folder)
	—> [KafkaServer id=0] started (kafka.server.KafkaServer) (This is the confirmation for Kafka server 			started successfully)

Create Topic:

	1. To Create Topic you need to run the following command:
		kafka-topics --bootstrap-server localhost:9092 --topic first_topic --create --partitions 3 
		--replication-factor 1
	2. To check the created topic list:
		kafka-topics --bootstrap-server localhost:9092 --list
	3. To check the complete details about topic:
		kafka-topics --bootstrap-server localhost:9092 --describe
Delete Topic:
	1. To delete the topic:
		kafka-topics --bootstrap-server localhost:9092 --topic second_topic --delete


Produce Data to topic:
	1. To produce the message to topic:
		kafka-console-producer --broker-list localhost:9092 --topic first_topic
		(—broker-list and —topic is Mandatory commands for producing)

Consume the messages from Topic:
	1. To consume the messages from topic:
		kafka-console-consumer --bootstrap-server localhost:9092 --topic first_topic
		(To get the latest messages i.e. Realtime streaming)
	2. To get all the messages from Topic:
		kafka-console-consumer --bootstrap-server localhost:9092 --topic first_topic --from-beginning (it gives all the messages from topic and realtime steam as well)	

Consumer Groups:

	1. To add consumer to group
		kafka-console-consumer --bootstrap-server localhost:9092 --topic first_topic —group 				[group-id]
		(Ex: kafka-console-consumer --bootstrap-server localhost:9092 --topic first_topic —group 			my-first-application-group)
	2. To get the consumer group details:
		—> Kafka-consumer-groups —bootstrap-server localhost:9092 —list
	3. To get the consumer group description :
		—> Kafka-consumer-groups —bootstrap-server localhost:9092 —describe —group [group-id]

To Reset the Offsets for Consumer Groups:

	—> Kafka-consumer-groups —bootstrap-server localhost:9092 —group [group_id (my-fisrt-application-group) ] —reset-offset —to-earliest —execute —topic [topic-name (first_topic) ]

—> To Shift particular number of offset : 
	Kafka-consumer-groups —bootstrap-server localhost:9092 —group [group_id (my-fisrt-application-group) ] —reset-offset —shift-by [no.of.offsets (2)]  —execute —topic [topic-name (first_topic) ]


Producer with keys:
	kafka-console-producer --broker-list 127.0.0.1:9092 --topic first_topic --property parse.key=true --		property key.separator=,
	> key,value
	> another key,another value

Consumer with Keys:
	kafka-console-consumer --bootstrap-server 127.0.0.1:9092 --topic first_topic --from-beginning --property print.key=true --property key.separator=,