# Webflux-Mongo-Client-Application

#It is a client side application to subscribe the data which is published by Server Application (Publisher)

#For this I have used Webclient Util class to subsribe the data from Publisher.
