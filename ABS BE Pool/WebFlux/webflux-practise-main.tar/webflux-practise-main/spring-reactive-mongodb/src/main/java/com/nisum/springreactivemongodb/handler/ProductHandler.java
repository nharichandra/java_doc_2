package com.nisum.springreactivemongodb.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Range;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.nisum.springreactivemongodb.dto.ProductDto;
import com.nisum.springreactivemongodb.exception.CustomException;
import com.nisum.springreactivemongodb.repository.ProductRepository;
import com.nisum.springreactivemongodb.utils.AppUtils;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class ProductHandler {

	@Autowired
	private ProductRepository productRepository;

	public Mono<ServerResponse> getOneProduct(ServerRequest request) {
		String productId = request.pathVariable("id");
		Mono<ProductDto> productMono = productRepository.findById(productId).map(AppUtils::entityToDto).switchIfEmpty(Mono.error(new CustomException("Object not found")));
		return ServerResponse.ok().contentType(MediaType.TEXT_EVENT_STREAM).body(productMono, ProductDto.class);
	}

	public Mono<ServerResponse> getProductInRange(ServerRequest request) {
//		Map<String, List<String>> params = request.queryParams();
	//	System.out.println("Hi");
		Double min = Double
				.parseDouble(request.queryParam("min").isPresent() ? request.queryParam("min").get() : "0.0");
		Double max = Double
				.parseDouble(request.queryParam("max").isPresent() ? request.queryParam("max").get() : "0.0");
		//System.out.println(min+" && "+max);
		Flux<ProductDto> productRangeFlux = productRepository.findByPriceBetween(Range.closed(min, max));
		//Flux<ProductDto> productRangeFlux = Flux.empty();
		return ServerResponse.ok().contentType(MediaType.TEXT_EVENT_STREAM).body(productRangeFlux, ProductDto.class);
	}

	public Mono<ServerResponse> getProducts(ServerRequest request) {
		Flux<ProductDto> productsFlux = productRepository.findAll().map(AppUtils::entityToDto);
		return ServerResponse.ok().contentType(MediaType.TEXT_EVENT_STREAM).body(productsFlux, ProductDto.class);
	}

	public Mono<ServerResponse> saveProduct(ServerRequest request) {
		Mono<ProductDto> productDtoMono = request.bodyToMono(ProductDto.class);
		Mono<ProductDto> finalMono = productDtoMono.map(AppUtils::dtoToEntity).flatMap(productRepository::insert)
				.map(AppUtils::entityToDto);
		return ServerResponse.ok().contentType(MediaType.TEXT_EVENT_STREAM).body(finalMono, ProductDto.class);
	}

	public Mono<ServerResponse> updateProduct(ServerRequest request) {
		Mono<ProductDto> productDtoMono = request.bodyToMono(ProductDto.class);
		String productId = request.pathVariable("id");
		Mono<ProductDto> finalMono = productRepository.findById(productId)
				.flatMap(p -> productDtoMono.map(AppUtils::dtoToEntity).doOnNext(e -> e.setId(productId)))
				.flatMap(productRepository::save).map(AppUtils::entityToDto);
		return ServerResponse.ok().contentType(MediaType.TEXT_EVENT_STREAM).body(finalMono, ProductDto.class);
	}
	
	public Mono<ServerResponse> deleteProduct(ServerRequest request) {
		String productId = request.pathVariable("id");
		Mono<Void> finalMono = productRepository.deleteById(productId);
		return ServerResponse.ok().contentType(MediaType.TEXT_EVENT_STREAM).body(finalMono, Void.class);
	}

}