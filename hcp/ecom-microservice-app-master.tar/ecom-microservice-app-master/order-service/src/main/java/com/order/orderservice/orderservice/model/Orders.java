package com.order.orderservice.orderservice.model;

import java.util.List;

public class Orders {
    private List<Order> orderList;

    public Orders(List<Order> orderList) {
        this.orderList = orderList;
    }

    public Orders() {
    }

    public List<Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }
}
