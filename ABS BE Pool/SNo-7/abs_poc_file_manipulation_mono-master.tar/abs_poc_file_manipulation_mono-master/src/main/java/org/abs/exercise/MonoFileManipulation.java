package org.abs.exercise;

public class MonoFileManipulation {
    public static void main(String[] args) {

      FileService.read("Subscription01.txt")
              .subscribe(Util.onNext(), Util.onError(), Util.onComplete());

        FileService.write("Subscription02.txt", "Hello ABS, How are you")
                .subscribe(Util.onNext(), Util.onError(), Util.onComplete());

        FileService.delete("Subscription03.txt")
                .subscribe(Util.onNext(), Util.onError(), Util.onComplete());
    }
}