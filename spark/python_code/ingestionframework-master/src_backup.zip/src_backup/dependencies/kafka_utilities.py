
from pyspark.streaming.kafka import KafkaUtils

def kafka_utils():
    pass