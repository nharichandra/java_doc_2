package com.nisum.livescorestream.router;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.nisum.livescorestream.handler.LiveScoreHandler;

@Configuration
public class RouterConfig {

    @Autowired
    private LiveScoreHandler liveScoreHandler;

//    @Autowired
//    private CustomerStreamHandler streamHandler;

    @Bean
    public RouterFunction<ServerResponse> routerFunction(){
        return RouterFunctions.route()
                .GET("/router/livescore",liveScoreHandler::getRouterLiveFeed)
                .build();

    }
}