package com.order.orderservice.orderservice.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class LineItem {

    private String lineItemNumber;
    private Integer orderQuantity;
    private String productId;
    private String productName;
    private Double price;
    private Double tax;

    public LineItem() {
    }

    public LineItem(String lineItemNumber, Integer orderQuantity, String productId,
                    String productName, Double price, Double tax) {
        this.lineItemNumber = lineItemNumber;
        this.orderQuantity = orderQuantity;
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.tax = tax;
    }



    public String getLineItemNumber() {
        return lineItemNumber;
    }

    public void setLineItemNumber(String lineItemNumber) {
        this.lineItemNumber = lineItemNumber;
    }

    public Integer getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(Integer orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    @Override
    public String toString() {
        return "LineItem{" +
                ", lineItemNumber='" + lineItemNumber + '\'' +
                ", orderQuantity=" + orderQuantity +
                ", productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", price=" + price +
                ", tax=" + tax +
                '}';
    }
}
