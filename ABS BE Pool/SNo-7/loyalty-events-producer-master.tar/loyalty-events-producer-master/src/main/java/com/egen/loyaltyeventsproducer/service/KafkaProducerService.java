package com.egen.loyaltyeventsproducer.service;

import com.egen.loyaltyeventsproducer.IService.IKafkaProducerService;
import com.egen.loyaltyeventsproducer.config.KafkaProducerConfig;
import com.egen.loyaltyeventsproducer.producer.LoyaltyRewardsProducer;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.stereotype.Service;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderOptions;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


@Service
public class KafkaProducerService implements IKafkaProducerService {

    private static final String TOPIC = "loyalty-rewards-info";
    private static KafkaSender<String, JsonNode> kafkaSender;

    @Autowired
    private KafkaProducerConfig KafkaProducerConfig;

    public  reactor.kafka.sender.KafkaSender<String, JsonNode> getKafkaSender(){
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, KafkaProducerConfig.getBootstrapper());
        props.put(ProducerConfig.CLIENT_ID_CONFIG, KafkaProducerConfig.getClientId());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        SenderOptions<String, JsonNode> senderOptions = SenderOptions.create(props);
        return reactor.kafka.sender.KafkaSender.create(senderOptions);
    }

    @Override
    public void generateKafkaMessages() {

        kafkaSender = getKafkaSender();
            LoyaltyRewardsProducer producer = new LoyaltyRewardsProducer();
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    producer.generateMessages(kafkaSender, TOPIC, 1);
                }
            }, 0, 4000);
    }
}
