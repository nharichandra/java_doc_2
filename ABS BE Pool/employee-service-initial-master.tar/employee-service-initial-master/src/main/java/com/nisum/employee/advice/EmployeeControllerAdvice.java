package com.nisum.employee.advice;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.nisum.employee.dto.ErrorMessage;
import com.nisum.employee.exceptions.ResourceNotFoundException;

/**
 * Employee advice for handling employee exceptions.
 * 
 * @author Rjosula
 *
 */
@RestControllerAdvice
public class EmployeeControllerAdvice extends ResponseEntityExceptionHandler {
    
    /**
     * Handler method when employee does not exist then this will be triggered
     * and returns the error message response.
     * @param ex exception
     * @param request web request
     * @return errorMessage response
     */
    @ExceptionHandler(value = {ResourceNotFoundException.class})
    public ResponseEntity<Object> resourceNotFoundException(
            ResourceNotFoundException ex, WebRequest request) {
        
        String description = "Employee not found with id : "
        + request.getParameter("id");
        ErrorMessage errorMesg = new ErrorMessage(HttpStatus.NOT_FOUND.value(),
                LocalDateTime.now(), ex.getMessage(), description);
        
        return new ResponseEntity<>(errorMesg, HttpStatus.NOT_FOUND);
    }
    
}
