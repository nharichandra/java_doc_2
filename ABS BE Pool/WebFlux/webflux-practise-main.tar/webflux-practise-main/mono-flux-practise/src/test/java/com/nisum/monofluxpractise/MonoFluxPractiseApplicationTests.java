package com.nisum.monofluxpractise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonoFluxPractiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
