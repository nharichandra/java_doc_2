package com.order.orderservice.orderservice.repository;

import com.order.orderservice.orderservice.model.Order;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
@RefreshScope
public interface OrderRepository extends MongoRepository<Order, String> {
}
