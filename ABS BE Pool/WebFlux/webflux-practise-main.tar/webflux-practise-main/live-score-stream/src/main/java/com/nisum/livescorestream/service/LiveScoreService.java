package com.nisum.livescorestream.service;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nisum.livescorestream.entity.LiveScore;
import com.nisum.livescorestream.repository.LiveScoreRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class LiveScoreService {

	@Autowired
	private LiveScoreRepository liveScoreRepository;
	
	public Flux<LiveScore> getLiveFeed() {
		return liveScoreRepository.findWithTailableCursorBy().delayElements(Duration.ofMillis(2500));

	}
	
	public Mono<LiveScore> saveLiveScore(Mono<LiveScore> liveScoreMono) {
		return liveScoreMono.flatMap(liveScoreRepository::insert);
	}

}
