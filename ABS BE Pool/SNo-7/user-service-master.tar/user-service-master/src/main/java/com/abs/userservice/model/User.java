package com.abs.userservice.model;

public class User {
}
