package com.abs.userservice.validation;

public class UserValidation {
}
