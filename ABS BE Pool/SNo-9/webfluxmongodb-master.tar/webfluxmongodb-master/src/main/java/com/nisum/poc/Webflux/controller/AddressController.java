package com.nisum.poc.Webflux.controller;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.model.AddressPayload;
import com.nisum.poc.Webflux.service.IAddressService;
import com.nisum.poc.Webflux.utils.ConstantUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class AddressController {
    @Autowired
    IAddressService addressService;

    @Autowired
    ConstantUtils constantUtils;


    @PostMapping("/saveaddress")
    public Mono<Address> createAddress(@RequestBody AddressPayload addressPayload){
        return addressService.createAddress(addressPayload);
    }

    @GetMapping("/alladdress")
    public Flux<Address> getAllAddress(){
         return addressService.getAllAddress();

    }
}
