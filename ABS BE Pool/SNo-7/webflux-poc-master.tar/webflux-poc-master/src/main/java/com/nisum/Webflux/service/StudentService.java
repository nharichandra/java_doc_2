package com.nisum.Webflux.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.nisum.Webflux.dao.AddressRepository;
import com.nisum.Webflux.dao.StudentRepository;
import com.nisum.Webflux.dao.SubjectRepository;
import com.nisum.Webflux.dto.StudentDTO;
import com.nisum.Webflux.model.Address;
import com.nisum.Webflux.model.Student;
import com.nisum.Webflux.model.Subject;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuple3;
import reactor.util.function.Tuples;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Autowired
	private ReactiveMongoTemplate reactiveMongoTemplate;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private SubjectRepository subjectRepository;

	public Mono<Student> createStudent(StudentDTO studentDto) {

		Student student = new Student();
		student.setId(studentDto.getId());
		student.setFirstName(studentDto.getFirstName());
		student.setLastName(studentDto.getLastName());
		student.setAge(studentDto.getAge());
		student.setPhoneNumbers(studentDto.getPhoneNumbers());

		Mono<Student> studentMono = studentRepository.save(student);
		List<Address> addressList = new ArrayList<Address>();
		List<Subject> subjectsList = new ArrayList<Subject>();
		studentMono.subscribe(std -> {
			studentDto.getAddresses().forEach(addr -> {
				Address address = new Address();
				address.setId(addr.getId());
				address.setAddress(addr.getAddress());
				address.setCity(addr.getCity());
				address.setAddressType(addr.getAddressType());
				address.setPincode(addr.getPincode());
				address.setStudentId(std.getId());
				addressList.add(address);

//				Mono<Address> add = addressRepository.save(address);
//				add.subscribe(a -> {
//					System.out.println("address after saving==" + a.getAddress());
//				});
			});
			studentDto.getSubjects().forEach(sub -> {
				Subject subject = new Subject();
				subject.setId(sub.getId());
				subject.setSubjectName(sub.getSubjectName());
				subject.setStudentId(std.getId());

				subjectsList.add(subject);

//				Mono<Subject> subMono = subjectRepository.save(subject);
//				subMono.subscribe(a -> {
//					System.out.println("address after saving==" + a.getSubjectName());
//				});
			});
			 Flux<Address> allAddress = addressRepository.saveAll(addressList);
			 Flux<Subject> allSubjects = subjectRepository.saveAll(subjectsList);
		});
		return studentMono;
	}

	public Mono<Student> updateStudent(Student student) {
		return studentRepository.save(student);
	}

	public Flux<Address> getAddressByStudentId(Long studentId) {
		return addressRepository.findByStudentId(studentId);
	}

	public Flux<StudentDTO> getAllStudents() {

		Flux<StudentDTO> response = studentRepository.findAll().flatMap(std -> {

			Flux<Address> address = addressRepository.findByStudentId(std.getId())
					.switchIfEmpty(Flux.just(new Address()));

			Flux<Subject> subjects = subjectRepository.findByStudentId(std.getId())
					.switchIfEmpty(Flux.just(new Subject()));

			StudentDTO dto = new StudentDTO();
			dto.setId(std.getId());
			dto.setFirstName(std.getFirstName());
			dto.setLastName(std.getLastName());
			dto.setAge(std.getAge());
			dto.setPhoneNumbers(std.getPhoneNumbers());

			dto.setAddresses(address.collectList().block());
			dto.setSubjects(subjects.collectList().block());

			Flux<StudentDTO> responseObject = Flux.just(dto);
			return responseObject;
		});

		return response;
	}

	public Mono<Student> findById(Long id) {

		Mono<Student> monoStudent = studentRepository.findById(id).zipWhen(stud -> {

			Flux<Address> studentAddress = addressRepository.findByStudentId(stud.getId())
					.switchIfEmpty(Flux.just(new Address()));

			Flux<Subject> subjects = subjectRepository.findByStudentId(stud.getId())
					.switchIfEmpty(Flux.just(new Subject()));

			return studentAddress.collectList().zipWith(subjects.collectList());
		}).map(tuple2 -> {
			Student s = tuple2.getT1();

			Tuple2<List<Address>, List<Subject>> stAddressAndSubjects = tuple2.getT2();

			List<Address> stAddress = stAddressAndSubjects.getT1();
			s.setAddress(stAddress);

			List<Subject> stSubjects = stAddressAndSubjects.getT2();
			s.setSubjects(stSubjects);

			return s;
		});

		return monoStudent;
	}

	public Mono<Student> findByIdZipWhen(Long id) {
		Mono<Student> student = studentRepository.findById(id).flatMap(
				std -> Mono.just(std).zipWith(addressRepository.findByStudentId(std.getId()).collectList(), (st, a) -> {
					st.setAddress(a);
					return st;
				}));

		return student;
	}

	public Mono<Tuple2<Student, List<Address>>> zipWhen(Long studentId) {

		Mono<Tuple2<Student, List<Address>>> monoStudent = studentRepository.findById(studentId).zipWhen(student -> {
			Flux<Address> studentAddress = addressRepository.findByStudentId(student.getId());
			return studentAddress.collectList();
		});
		return monoStudent;
	}

	public Mono<Tuple3<Student, List<Address>, List<Subject>>> zipWith(Long studentId) {

		Mono<Tuple3<Student, List<Address>, List<Subject>>> stdWithAddressAndSubjects = studentRepository
				.findById(studentId).zipWhen(stud -> {

					Flux<Address> studentAddress = addressRepository.findByStudentId(stud.getId())
							.switchIfEmpty(Flux.just(new Address()));

					Flux<Subject> subjects = subjectRepository.findByStudentId(stud.getId())
							.switchIfEmpty(Flux.just(new Subject()));

					return studentAddress.collectList().zipWith(subjects.collectList());
				}).map(tuple3 -> {

					Student student = tuple3.getT1();

					Tuple2<List<Address>, List<Subject>> stAddressAndSubjects = tuple3.getT2();

					List<Address> stAddress = stAddressAndSubjects.getT1();

					List<Subject> stSubjects = stAddressAndSubjects.getT2();

					return Tuples.of(student, stAddress, stSubjects);
				});
		return stdWithAddressAndSubjects;
	}

	public Flux<Student> fetchStudents(String name) {
		Query query = new Query().with(Sort.by(Collections.singletonList(Sort.Order.asc("age"))));
		query.addCriteria(Criteria.where("firstName").regex(name));
		return reactiveMongoTemplate.find(query, Student.class);
	}

	public Flux<Student> getStudentsByName(String name) {

		String[] names = name.split(",");
		Flux<Student> allStudents = Flux.fromArray(names).flatMap(n -> studentRepository.findByFirstName(n));
		return allStudents;
	}

	public Flux<String> transformMap() {
		List<String> names = Arrays.asList("google", "facebook", "Stackoverflow");
		Flux<String> mapNames = Flux.fromIterable(names).filter(name -> name.length() > 5).map(n -> n.toUpperCase())
				.log();
		return mapNames;

	}

	public Flux<String> transformUsingFlatMap() {
		List<String> names = Arrays.asList("google ", "abc", "fb", " stackoverflow");
		Flux<String> names$ = Flux.fromIterable(names).filter(name -> name.length() > 5).flatMap(name -> {
			return Mono.just(name.toUpperCase());
		});
		return names$;
	}

	public Flux<String> combineUsingMerge() {
		Flux<String> names1$ = Flux.just("JP ", " Nisum ", "Tech ");
		Flux<String> names2$ = Flux.just(" Morgan ", " Technologies ", " Mahindra");
		Flux<String> names$ = Flux.merge(names1$, names2$).log();
		
		Flux<Student> students= Flux.merge(Flux.just(new Student()),Flux.just(new Student()));
		return names$;
	}

	public Flux<String> concat() {
		Flux<String> names1$ = Flux.just("JP ", " Nisum ", "Tech ");
		Flux<String> names2$ = Flux.just("Morgan ", " Technologies ", " Mahindra");
		Flux<String> names$ = Flux.concat(names1$, names2$).log();
		return names$;
	}

	public Flux<String> combineWithZip() {
		Flux<String> names1$ = Flux.just("JP ", " Nisum ", "Tech ");
		Flux<String> names2$ = Flux.just("Morgan ", " Technologies ", " Mahindra");
		Flux<String> names$ = Flux.zip(names1$, names2$, (n1, n2) -> {
			return n1.concat(" ").concat(n2);
		}).log();
		
//		Flux<StudentDTO> response = Flux.zip(students, studentAddresses, studentSubjects).flatMap(st -> {
//			StudentDTO dto = new StudentDTO();
//			System.out.println("st=="+st);
//			dto.setFirstName(st.getT1().getFirstName());
//			dto.setLastName(st.getT1().getLastName());
//			dto.setAge(st.getT1().getAge());
//			dto.setPhoneNumbers(st.getT1().getPhoneNumbers());
//
//			dto.setAddresses(studentAddresses.collectList().block());
//			dto.setSubjects(studentSubjects.collectList().block());
//
//			Flux<StudentDTO> responseObject = Flux.just(dto);
//			return responseObject;
//		});
		return names$;
	}

	public Flux<Student> getAllStudentsRouting() {

		return studentRepository.findAll();
	}
	
	public Flux<Tuple2<Tuple2<Student, Address>, Subject>> zipWith() {

		Flux<Student> students = studentRepository.findAll();

		Flux<Address> studentAddresses = students.flatMap(a -> addressRepository.findByStudentId(a.getId()))
				.switchIfEmpty(Flux.just(new Address()));

		Flux<Subject> studentSubjects = students.flatMap(a -> subjectRepository.findByStudentId(a.getId()))
				.switchIfEmpty(Flux.just(new Subject()));

		Flux<Tuple2<Student, Address>> studentsWithAddress = students.zipWith(studentAddresses);

		studentsWithAddress.subscribe(std -> {
			System.out.println("Name with Address==" + std.getT1().getFirstName() + "--" + std.getT2().getAddress());
		});

		Flux<Tuple2<Tuple2<Student, Address>, Subject>> studentsAndAddressWithSubjects = studentsWithAddress
				.zipWith(studentSubjects);

		studentsAndAddressWithSubjects.subscribe(std -> {
			System.out.println(
					"Name with Subject==" + std.getT1().getT1().getFirstName() + "--" + std.getT2().getSubjectName());
		});

		return studentsAndAddressWithSubjects;
	}

}
