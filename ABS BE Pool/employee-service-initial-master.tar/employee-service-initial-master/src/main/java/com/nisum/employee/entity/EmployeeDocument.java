package com.nisum.employee.entity;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.nisum.employee.dto.Address;

import lombok.Getter;
import lombok.Setter;

/**
 * Employee Document.
 * 
 * @author Rjosula
 *
 */
@Document("employeeDocument")
@Setter
@Getter
public class EmployeeDocument {

    public static final String SEQUENCE_NAME = "employeeSequence";
    
    @Id
    private Long employeeId;
    private String employeeName;
    private List<Address> employeeAddress;
    private long employeeSalary;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    private String departmentName;
    
    /*public Optional<Long> getEmployeeId() {
        return Optional.ofNullable(employeeId);
    }
    public Optional<String> getEmployeeName() {
        return Optional.ofNullable(employeeName);
    }
    public Optional<List<Address>> getEmployeeAddress() {
        return Optional.ofNullable(employeeAddress);
    }
    public Optional<Long> getEmployeeSalary() {
        return Optional.ofNullable(employeeSalary);
    }
    public Optional<LocalDateTime> getCreatedDate() {
        return Optional.ofNullable(createdDate);
    }
    public Optional<LocalDateTime> getModifiedDate() {
        return Optional.ofNullable(modifiedDate);
    }
    public Optional<String> getDepartmentName() {
        return Optional.ofNullable(departmentName);
    }*/
    
}
