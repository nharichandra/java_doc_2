package com.nisum.poc.Webflux.config;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Student;
import io.netty.handler.codec.http.websocketx.extensions.compression.WebSocketClientCompressionHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Configuration
@EnableScheduling
@Slf4j
public class WebclientEx {


    @Scheduled(initialDelay = 1000,fixedDelay = 2000)
    public void getAllStudents(){
        log.info("----------------------------------in scheduler method--------------------------------");
        WebClient client = WebClient.create("http://localhost:4042");
        Flux<Address> addressFlux = client.get().uri("/alladdress").accept(MediaType.TEXT_EVENT_STREAM).retrieve().bodyToFlux(Address.class);
        //converting Flux to Mono using next()
        Mono<Address> addressMono = client.get().uri("/alladdress").accept(MediaType.TEXT_EVENT_STREAM).retrieve().bodyToFlux(Address.class).next();
        addressFlux.filter(a -> a.getCity().equalsIgnoreCase("hyd")).subscribe(a -> System.out.println(a.toString()));
        //return studentFlux;
    }

}
