package com.egen.loyaltyeventsproducer.controller;

import com.egen.loyaltyeventsproducer.config.KafkaProducerConfig;
import com.egen.loyaltyeventsproducer.service.KafkaProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/loyalty/kafka")
public class KafkaProducerController {
    @Autowired
    private KafkaProducerService kafkaProducerService;

    @GetMapping("/producer")
    public void generateKafkaMessages()
    {
        kafkaProducerService.generateKafkaMessages();
    }
}
