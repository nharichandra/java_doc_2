package com.nisum.Webflux.dao;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import com.nisum.Webflux.model.Address;

import reactor.core.publisher.Flux;

@Repository
public interface AddressRepository extends ReactiveMongoRepository<Address, Long>{

	Flux<Address> findByStudentId(Long studentId);
}
