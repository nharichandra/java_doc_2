package com.order.orderservice.orderservice.model;

public class OrderSummery {

    private String customerName;
    private String productName;
    private String productDesc;
    private Double price;

    public OrderSummery() {
    }

    public OrderSummery(String customerName, String productName, String productDesc, Double price) {
        this.customerName = customerName;
        this.productName = productName;
        this.productDesc = productDesc;
        this.price = price;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "OrderSummery{" +
                "customerName='" + customerName + '\'' +
                ", productName='" + productName + '\'' +
                ", productDesc='" + productDesc + '\'' +
                ", price=" + price +
                '}';
    }
}
