package com.nisum.poc.Webflux.service;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Subject;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public interface ISubjectsService {
    Mono<Subject> createSuject(Subject subject);

    Flux<Subject> getAllSubjects();
}
