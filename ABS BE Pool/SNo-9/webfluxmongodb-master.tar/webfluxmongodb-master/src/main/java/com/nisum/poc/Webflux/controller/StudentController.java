package com.nisum.poc.Webflux.controller;

import com.nisum.poc.Webflux.entity.Student;
import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.model.StudentPayload;
import com.nisum.poc.Webflux.model.StudentResponsePayload;
import com.nisum.poc.Webflux.service.IStudentService;
import com.nisum.poc.Webflux.service.ISubjectsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@RestController
public class StudentController {

    @Autowired
    IStudentService studentService;

    @PostMapping("/saveStudent")
    public Mono<Student> creatStudent(@RequestBody StudentPayload studentPayload){
        return studentService.createStudent(studentPayload);

    }

    @GetMapping("/allStudents")
    public Flux<StudentResponsePayload> getAllStudents(){
        return studentService.getAllStudents();

    }
    @GetMapping("/concatEx")
    public  Flux<String> concatFlux(){
        return studentService.concat();

    }

    @GetMapping("/mergeEx")
    public  Flux<String> mergeFlux(){
        return studentService.merge().log();

    }
    @GetMapping("/zipEx")
    public  Flux<Integer> zip(){
        return studentService.combineWithZip();
    }

    @GetMapping("/zipWithEx")
    public  Flux<Integer> zipWith(){
        Flux<Integer> evenNumbers = Flux
                .range(1, 5)
                .filter(x -> x % 2 == 0); // i.e. 2, 4

        Flux<Integer> oddNumbers = Flux
                .range(1, 5)
                .filter(x -> x % 2 > 0);//1,3,5
        Flux<Integer> concatIntegers = Flux.concat(evenNumbers,oddNumbers);
        Flux<Integer> mergefIntegers = Flux.merge(evenNumbers,oddNumbers);
        Flux<Integer> zipIntegers = Flux.zip(evenNumbers,oddNumbers,(a,b)->a*b).log();
        //flux to mono last(),next(),elementAt(1), haselements() haselement(1),
        Mono<Integer> integerMono = oddNumbers.next();
        Flux<Integer> zipwithIntegers = evenNumbers.zipWith(oddNumbers,(a,b)->a*b);//2,12
        return zipwithIntegers;
    }

    @GetMapping("/flatMap")
    public Flux<String> transformUsingFlatMap() {
        List<String> names = Arrays.asList("google ", "abc", "fb", " stackoverflow"," bhanuchander"," reddy");
        Flux<String> namess = Flux.fromIterable(names).filter(name -> name.length() >= 5).flatMap(name -> {
            return Flux.just(name.toUpperCase()).
                    delayElements(Duration.ofMillis(151)).log();
        });
        return namess;
    }
}
