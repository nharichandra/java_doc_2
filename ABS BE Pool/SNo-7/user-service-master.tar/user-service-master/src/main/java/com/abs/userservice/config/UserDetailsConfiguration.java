package com.abs.userservice.config;

public class UserDetailsConfiguration {
}
