package com.nisum.spring.kafka.api;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.spring.kafka.api.config.CustomPartitioner;

@SpringBootApplication
@RestController
public class KafkaPublisherApplication {

	@Autowired
	private KafkaTemplate<String, Object> template;
	
	@Autowired
	private Producer<String, String> producer;

	private String topic = "sample1";

	@GetMapping("/publish/{name}")
	public String publishMessage(@PathVariable String name) {
		template.send(topic, "Hi " + name + " Welcome to Nisum");
		return "Data published";
	}
	 
	@GetMapping("/publishInPartision/{name}")
	public String publishMessageInSpecificPartision(@PathVariable String name) {
		
		producer.send(new ProducerRecord<>("test",0, "hai how are you","value"+1 ));
		//producer.close();
		
		return "Data published";
	}

	/*
	 * @GetMapping("/publishJson") public String publishMessage() { User user = new
	 * User(2532, "User88", new String[] { "Bangalore", "BTM", "house 90" });
	 * template.send(topic, user); return "Json Data published"; }
	 */
	public static void main(String[] args) {
		SpringApplication.run(KafkaPublisherApplication.class, args);
	}
}
