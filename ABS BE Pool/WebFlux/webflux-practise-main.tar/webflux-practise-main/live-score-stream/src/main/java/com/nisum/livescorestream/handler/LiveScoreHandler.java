package com.nisum.livescorestream.handler;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.nisum.livescorestream.entity.LiveScore;
import com.nisum.livescorestream.repository.LiveScoreRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class LiveScoreHandler {

	@Autowired
	private LiveScoreRepository liveScoreRepository;
	

	public Mono<ServerResponse> getRouterLiveFeed(ServerRequest request) {
		Flux<LiveScore> productsFlux =liveScoreRepository.findWithTailableCursorBy().delayElements(Duration.ofMillis(2500));
		return ServerResponse.ok().contentType(MediaType.TEXT_EVENT_STREAM).body(productsFlux, LiveScore.class);
	}



}