package com.nisum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxUsecasesApplicationTests {

	@Test
	void contextLoads() {
	}

}
