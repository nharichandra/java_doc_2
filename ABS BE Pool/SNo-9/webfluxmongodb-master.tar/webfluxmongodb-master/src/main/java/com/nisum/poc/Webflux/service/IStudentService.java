package com.nisum.poc.Webflux.service;

import com.nisum.poc.Webflux.entity.Student;
import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.model.StudentPayload;
import com.nisum.poc.Webflux.model.StudentResponsePayload;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public interface IStudentService {

    Mono<Student> createStudent(StudentPayload studentPayload);

    Flux<StudentResponsePayload> getAllStudents();
    Flux<String> concat();

    Flux<String> merge();
    public Flux<Integer> combineWithZip();
}
