package com.nisum.kafkaexample.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nisum.kafkaexample.entity.Product;
import com.nisum.kafkaexample.repository.ProductRepository;

@Component
public class KafkaConsumerService {
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
    private KafkaListenerEndpointRegistry kafkaListenerEndpointRegistry;
	
	Logger log = LoggerFactory.getLogger(KafkaConsumerService.class);

//	@KafkaListener(topics = "test-1-topic", groupId = "group_id")
//	public void consume(String message) {
//		log.info("message = " + message);
////		JSONParser parser = new JSONParser();  
////		JSONObject json = (JSONObject) parser.parse(stringToParse);  
////		productRepository.save(null)
//	}
	
	@KafkaListener(topics = "test-1-topic",id = "full-part-id", groupId = "group_id",
            containerFactory = "kafkaListenerStringContainerFactory")
    public void listenasString(ConsumerRecord<String, String> consumerRecord,  
            Acknowledgment acknowledgment) throws ParseException, JsonMappingException, JsonProcessingException {
        log.info("message :: "+consumerRecord.value());
//        JSONParser parser = new JSONParser();  
//        JSONObject json = (JSONObject) parser.parse(consumerRecord.value()); 
        ObjectMapper objectMapper=new ObjectMapper();
        Product product=objectMapper.readValue(consumerRecord.value(),Product.class);
        productRepository.save(product);
        //if(false) {
        //consumer.commitAsync();
       acknowledgment.acknowledge();
//       MessageListenerContainer listenerContainer = kafkaListenerEndpointRegistry.getListenerContainer("full-part-id");
//       listenerContainer.stop();
        //}
    }
	
//	@Scheduled(fixedDelay = 30000, initialDelay = 15000)
//    public void schedularMsgConsumeKakfa() throws Exception {
//        MessageListenerContainer listenerContainer = kafkaListenerEndpointRegistry.getListenerContainer("full-part-id");
//        listenerContainer.start();
//    }
}
