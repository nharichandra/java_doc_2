package com.customer.customerservice.service;

import com.customer.customerservice.exception.CustomerNotFoundException;
import com.customer.customerservice.model.Customer;
import com.customer.customerservice.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService{

    @Autowired
    CustomerRepository customerRepository;

    @Override
    public Customer saveCustomer(Customer customer) {
        customerRepository.save(customer);
        return customer;
    }

    @Override
    public List<Customer> getAllCustomers() {

        return customerRepository.findAll();
    }

    @Override
    public Customer getCustomerById(String customerId) {
        Optional<Customer> customer = customerRepository.findById(customerId);
        if(!customer.isPresent()){
            throw new CustomerNotFoundException("Customer Not found with given Customer Id :"+customerId);
        }
        return customer.get();
    }
}
