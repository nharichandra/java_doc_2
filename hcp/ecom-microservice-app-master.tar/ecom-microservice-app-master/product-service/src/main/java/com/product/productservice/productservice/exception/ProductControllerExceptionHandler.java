package com.product.productservice.productservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class ProductControllerExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(ProductNotFoundException.class)
    public ResponseEntity<?> handleCustomerNotFoundException(ProductNotFoundException productNotFoundException,
                                                                                     WebRequest webRequest){

        ExceptionResponce exceptionResponce = new ExceptionResponce(productNotFoundException.getMessage(), webRequest.getDescription(false));
        return new ResponseEntity<>(exceptionResponce, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleGlobalException(Exception exception, WebRequest webRequest){
        ExceptionResponce responce = new ExceptionResponce(exception.getMessage(), webRequest.getDescription(false));
        return new ResponseEntity<>(responce, HttpStatus.INTERNAL_SERVER_ERROR);

    }
}
