package com.customer.customerservice.controller;

import com.customer.customerservice.exception.CustomerNotFoundException;
import com.customer.customerservice.model.Customer;
import com.customer.customerservice.model.Customers;
import com.customer.customerservice.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @PostMapping("/createCustomer")
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer){
       Customer savedCustomer =  customerService.saveCustomer(customer);
       if(savedCustomer == null){
           throw new RuntimeException("Error While Creating the Customer. Please check the Input");
       }
       return new ResponseEntity<Customer>(savedCustomer, HttpStatus.CREATED);
    }

    @GetMapping("/allCustomers")
    public ResponseEntity<Customers> getAllCustomers() throws CustomerNotFoundException {
        List<Customer> customerList = customerService.getAllCustomers();
        if (customerList == null){
            throw new CustomerNotFoundException("No Customer found with the Input data");
        }
        Customers customers = new Customers();
        customers.setCustomerList(customerList);
        return new ResponseEntity<Customers>(customers, HttpStatus.OK);
    }


    @GetMapping("/{customerId}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable("customerId") String customerId) throws CustomerNotFoundException {
        Customer customer = customerService.getCustomerById(customerId);
        if (customer == null){
            throw new CustomerNotFoundException("No Customer Found with Given Id : "+customerId);
        }
        return new ResponseEntity<Customer>(customer, HttpStatus.OK);
    }
}
