package com.nisum.poc.Webflux.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressPayload {
    private Integer id;
    private String address;
    private String city;
    private String pinCode;
    private String addressType;
    private Long studentId;
}
