package com.example.demo.repository;

import com.example.demo.model.Employee;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Repository
public interface EmployeeRepository extends ReactiveMongoRepository<Employee, Integer> {

    Flux<Employee> findAll();
    @Query(value = "{'sal' : ?0}")
    Flux<Employee> findAllBySal(Integer sal);
    Mono<Employee> findById();
}
