package com.nisum.employee.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.nisum.employee.dto.Employee;
import com.nisum.employee.entity.EmployeeDocument;
import com.nisum.employee.util.EmpUtility;

@Service
public class EmployeeQueryRepositoryImpl implements EmployeeQueryRepository {

    /** Mongo template for db operations. */
    @Autowired
    public MongoTemplate mongoTemplate;
    
    /**
     * Gets all employees matching the input department name
     * @param departmentName department name
     * @return list of all employees
     */
    @Override
    public List<Employee> getAllEmployeesByDept(String departmentName) {
        Query query = new Query();
        query.addCriteria(Criteria.where("departmentName").is(departmentName));
        List<EmployeeDocument> employeeDocuments = mongoTemplate.find(query,
                EmployeeDocument.class);
        System.out.println(employeeDocuments);
        
        return EmpUtility.provideEmployeeDto(employeeDocuments);
    }
    
    /**
     * Checks whether the employee address field does not exists and returns
     * employees who fall under that criteria.
     * 
     * @return list of all employees
     */
    public List<Employee> getEmployeesWhoDidNotUpdatedAddresses() {
        
        Query query = new Query();
        query.addCriteria(Criteria.where("employeeAddress").exists(false));
        List<EmployeeDocument> employeeDocuments = mongoTemplate.find(query,
                EmployeeDocument.class);
        System.out.println(employeeDocuments);
        return EmpUtility.provideEmployeeDto(employeeDocuments);
    }
    
    /**
     * Updates the employee document and returns the employee dto.
     * 
     * @param emplDoc employee document to get updated
     */
    @Override
    public Employee updateEmployee(EmployeeDocument emplDoc) {
        Query query = new Query().addCriteria(Criteria.where("employeeId")
                .is(emplDoc.getEmployeeId()));
        
        Update updateDefinition = new Update()
                .set("employeeSalary", emplDoc.getEmployeeSalary())
                .set("employeeAddress", emplDoc.getEmployeeAddress())
                .set("modifiedDate", LocalDateTime.now());
        FindAndModifyOptions options = new FindAndModifyOptions()
                .returnNew(true).upsert(true);
        
        EmployeeDocument document = mongoTemplate
                .findAndModify(query, updateDefinition, options,
                        EmployeeDocument.class);
        
        return EmpUtility.provideEmployee.apply(document);
    }
}
