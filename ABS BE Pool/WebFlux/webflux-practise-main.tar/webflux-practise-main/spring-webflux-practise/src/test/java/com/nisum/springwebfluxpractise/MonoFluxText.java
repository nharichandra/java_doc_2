package com.nisum.springwebfluxpractise;

import org.junit.Ignore;
import org.junit.jupiter.api.Test;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class MonoFluxText {
	@Test
	public void testMono1() {
		Mono<String> monoStr =  Mono.just("Nisum").log(); // Mono and Flux are publishers
		monoStr.subscribe(System.out::println);
	}
	
	//@Test
	//@Ignore
	public void testMono2() {
		Mono<?> monoStr =  Mono.just("Nisum").then(Mono.error(new RuntimeException("Custom Exception"))).log(); // Mono and Flux are publishers
		monoStr.subscribe(System.out::println,e->System.out.println(e.getMessage()));
	}
	
	@Test
	public void testFlux1() {
		Flux<String> fluxStr = Flux.just("Test 1","Test 2","Test 3","Test 4").concatWithValues("Test 5")
				//.concatWith(Flux.error(new RuntimeException("Custom Exception")))
				.log();
		fluxStr.subscribe(System.out::println,e->System.out.println(e.getMessage()));
	}

}
