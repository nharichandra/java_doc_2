package com.nisum.poc.Webflux.service.impl;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Student;
import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.model.StudentPayload;
import com.nisum.poc.Webflux.model.StudentResponsePayload;
import com.nisum.poc.Webflux.repository.AddressRepository;
import com.nisum.poc.Webflux.repository.StudentRepository;
import com.nisum.poc.Webflux.repository.SubjectRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

import static org.mockito.Mockito.*;

class StudentServiceImplTest {
    @Mock
    StudentRepository studentRepository;
    @Mock
    AddressRepository addressRepository;
    @Mock
    SubjectRepository subjectRepository;
    @Mock
    Logger log;
    @InjectMocks
    StudentServiceImpl studentServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
/*

    @Test
    void testCreateStudent() {
        Mono<Student> result = studentServiceImpl.createStudent(new Student(Long.valueOf(1), "firstName", "lastName", Integer.valueOf(0), List.of("String"), List.of(new Address(Long.valueOf(1), "address", "city", "pinCode", "addressType", Long.valueOf(1))), List.of(new Subject(Long.valueOf(1), "subjectName", Long.valueOf(1)))));
        Assertions.assertEquals(null, result);
    }
*/

    @Test
    void testGetAllStudents() {
        when(addressRepository.findByStudentId(anyLong())).thenReturn(null);
        when(subjectRepository.findByStudentId(anyLong())).thenReturn(null);

        Flux<StudentResponsePayload> result = studentServiceImpl.getAllStudents();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testConcat() {
        Flux<String> result = studentServiceImpl.concat();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testMerge() {
        Flux<String> result = studentServiceImpl.merge();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testCombineWithZip() {
        Flux<Integer> result = studentServiceImpl.combineWithZip();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testCombineWithZipChara() {
        Mono<String> result = studentServiceImpl.combineWithZipChara();
        Assertions.assertEquals(null, result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme