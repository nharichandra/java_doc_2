package com.abs.userservice.entity;

public class UserDetails {
}
