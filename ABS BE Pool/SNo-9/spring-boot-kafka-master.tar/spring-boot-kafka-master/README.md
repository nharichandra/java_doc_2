# Spring Boot Kafka

Spring Boot kafka 


Normal Kafka POC with producer and consumer with one restend point to emmit the data.
