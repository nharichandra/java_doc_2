# WebFlux-MongoDB Aggregations

Create project with Spring boot Webflux wit MongoDB database.

Implemented using webflux methods such as zip,zipWith,zipWhen,subscribe

=> Models 1.Student 2.Address 3.Subject 

Employee End points:  
1.http://localhost:8080/student/create
2.http://localhost:8080/student/create
3.http://localhost:8080/student/update
4.http://localhost:8080/student/getById/{studentId}
5.http://localhost:8080/student/getAll
6.http://localhost:8080/student/searchNames/{name}
7.http://localhost:8080/student/searchNamesByOrder/{name}
8.http://localhost:8080/student/searchNamesWithZip/{studentId}
9.http://localhost:8080/student/getMapResults
10.http://localhost:8080/student/getFlatMapResults

Address End Points:

1.http://localhost:8080/address/create
2.http://localhost:8080/address/getAll

Subjects End points:

1.http://localhost:8080/subject/create
2.http://localhost:8080/subject/getAll
