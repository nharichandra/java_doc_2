package com.egen.loyaltyeventsproducer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class KafkaProducerConfig {

    @Value("${bootstrap.server}")
    private String bootstrapper;
    @Value("${kafka.clientId}")
    private String clientId;

    public String getBootstrapper() {
        return bootstrapper;
    }

    public void setBootstrapper(String bootstrapper) {
        this.bootstrapper = bootstrapper;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }
}
