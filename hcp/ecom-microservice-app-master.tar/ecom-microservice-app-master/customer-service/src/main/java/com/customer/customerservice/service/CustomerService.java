package com.customer.customerservice.service;

import com.customer.customerservice.model.Customer;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface CustomerService {

    public Customer saveCustomer(Customer customer);
    public List<Customer> getAllCustomers();
    public Customer getCustomerById(String customerId);
}
