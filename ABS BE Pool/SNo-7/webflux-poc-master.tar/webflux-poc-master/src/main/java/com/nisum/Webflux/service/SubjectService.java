package com.nisum.Webflux.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nisum.Webflux.dao.SubjectRepository;
import com.nisum.Webflux.model.Subject;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class SubjectService {

	
	@Autowired
	private SubjectRepository subjectRepository;

	public Mono<Subject> createSubject(Subject subject) {
		return subjectRepository.save(subject);
	}

	public Flux<Subject> getAll() {
		return subjectRepository.findAll();
	}

	public Mono<Subject> findById(Long id) {
		return subjectRepository.findById(id);
	}
}
