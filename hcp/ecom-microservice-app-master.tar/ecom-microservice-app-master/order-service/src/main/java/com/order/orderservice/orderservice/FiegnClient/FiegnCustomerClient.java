package com.order.orderservice.orderservice.FiegnClient;

import com.order.orderservice.orderservice.model.Address;
import com.order.orderservice.orderservice.model.Customer;
import com.order.orderservice.orderservice.model.Customers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;


@FeignClient(value = "customer-service", fallback = FiegnCustomerClientFallBack.class)
public interface FiegnCustomerClient {
    @GetMapping("/api/customer/allCustomers")
    public Customers getAllCustomers();
}

@Component
class FiegnCustomerClientFallBack implements FiegnCustomerClient {
    @Override
    public Customers getAllCustomers(){
        Customers customers = new Customers();
        customers.setCustomerList(Arrays.asList(new Customer("0","Fall Back Customer","Fall Back Email",
                                    Arrays.asList(new Address("FallBack Address Line1", "FallBack City","FallBack State",0L,"FallBack Country","fallBack type")))));
        return customers;
    }
}
