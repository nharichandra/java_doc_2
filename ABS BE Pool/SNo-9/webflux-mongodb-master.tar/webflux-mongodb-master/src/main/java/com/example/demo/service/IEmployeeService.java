package com.example.demo.service;

import com.example.demo.model.Employee;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface IEmployeeService {

    Flux<Employee> findAll();
    Mono<Employee> findEmployeeById( Integer id);
    void createEmp(Employee employee);
}
