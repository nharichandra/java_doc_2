from pyspark.sql import SparkSession
from pyspark.conf import SparkConf
import configparser


def spark_conf(property_file):
    prop = configparser.ConfigParser()
    prop.read(property_file)
    """ tbd """

spark_session= SparkSession.builder.appName('Data-Ingestion').getOrCreate()
         #.config()\   # .enableHiveSupport()\

spark_context = spark_session.sparkContext
spark_conf = spark_session.conf




