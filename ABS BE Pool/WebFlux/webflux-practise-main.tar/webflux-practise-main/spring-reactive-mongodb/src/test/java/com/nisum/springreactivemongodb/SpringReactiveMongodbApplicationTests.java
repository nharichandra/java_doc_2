package com.nisum.springreactivemongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactiveMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
