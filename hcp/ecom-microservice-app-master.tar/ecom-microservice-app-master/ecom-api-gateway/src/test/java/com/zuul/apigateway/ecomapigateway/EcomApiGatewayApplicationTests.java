package com.zuul.apigateway.ecomapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
