Here, We have required information about this ApacheKafkaSpringBoot project

1. Its all about integrating Kafka with Spring Boot.
2. Configuration inforamtion about bootstrap kafka server, producer , consumer, topic ... added in application.properties file.
3. Implemented rest controller and publisher service components to publish messages to kafka cluster.
4. Implemented consumer service to consume / subsribe messages from Kafka cluster/ broker.
5. Test the functionality using Postman or browser

Sample Test URL's:
------------------

http://localhost:8080/api/v1/kafka/publish?message=hello%20world
