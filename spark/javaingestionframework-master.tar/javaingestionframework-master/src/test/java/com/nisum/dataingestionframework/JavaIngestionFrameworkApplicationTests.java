package com.nisum.dataingestionframework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaIngestionFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
