package com.nisum.poc.Webflux.controller;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Student;
import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.model.AddressPayload;
import com.nisum.poc.Webflux.model.StudentPayload;
import com.nisum.poc.Webflux.model.StudentResponsePayload;
import com.nisum.poc.Webflux.model.SubjectPayload;
import com.nisum.poc.Webflux.service.IStudentService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

import static org.mockito.Mockito.*;

class StudentControllerTest {
    @Mock
    IStudentService studentService;
    @InjectMocks
    StudentController studentController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /*@Test
    void testCreatStudent() {
        when(studentService.createStudent(any())).thenReturn(null);

        Mono<Student> result = studentController.creatStudent(new Student(Long.valueOf(1), "firstName", "lastName", Integer.valueOf(0), List.of("String"), List.of(new AddressPayload(1, "address", "city", "pinCode", "addressType", Long.valueOf(1))), List.of(new SubjectPayload(1, "subjectName", Long.valueOf(1)))));
        Assertions.assertEquals(null, result);
    }*/

    @Test
    void testGetAllStudents() {
        when(studentService.getAllStudents()).thenReturn(null);

        Flux<StudentResponsePayload> result = studentController.getAllStudents();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testConcatFlux() {
        when(studentService.concat()).thenReturn(null);

        Flux<String> result = studentController.concatFlux();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testMergeFlux() {
        when(studentService.merge()).thenReturn(null);

        Flux<String> result = studentController.mergeFlux();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testZip() {
        when(studentService.combineWithZip()).thenReturn(null);

        Flux<Integer> result = studentController.zip();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testZipWith() {
        Flux<Integer> result = studentController.zipWith();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testTransformUsingFlatMap() {
        Flux<String> result = studentController.transformUsingFlatMap();
        Assertions.assertEquals(null, result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme