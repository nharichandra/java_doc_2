package com.nisum.poc.Webflux.service.impl;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Student;
import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.mapper.AllMapper;
import com.nisum.poc.Webflux.model.AddressPayload;
import com.nisum.poc.Webflux.model.StudentPayload;
import com.nisum.poc.Webflux.model.StudentResponsePayload;
import com.nisum.poc.Webflux.repository.AddressRepository;
import com.nisum.poc.Webflux.repository.StudentRepository;
import com.nisum.poc.Webflux.repository.SubjectRepository;
import com.nisum.poc.Webflux.service.IStudentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Service
@Slf4j
public class StudentServiceImpl implements IStudentService {


    @Autowired
    StudentRepository studentRepository;
    @Autowired
    AddressRepository addressRepository;
    @Autowired
    SubjectRepository subjectRepository;

    @Autowired
    AllMapper allMapper;
    @Override
    public Mono<Student> createStudent(StudentPayload studentPayload) {
        Student student1 = new Student();
        student1.setId(studentPayload.getId());
        student1.setAge(studentPayload.getAge());
        student1.setFirstName(studentPayload.getFirstName());
        student1.setLastName(studentPayload.getLastName());
        student1.setPhoneNumbers(studentPayload.getPhoneNumbers());
        Mono<Student> studentMono = studentRepository.save(allMapper.modelToEntity(studentPayload));

        List<Address> addressList = new ArrayList<>();
        List<Subject> subjectList = new ArrayList<>();

        studentMono.subscribe(studentmono -> {
            studentPayload.getAddresses().forEach(address -> {
                addressList.add(allMapper.modelToEntity(address));
            });
            studentPayload.getSubjects().forEach(sub -> {
                subjectList.add(allMapper.modelToEntity(sub));
            });
            Flux<Address> addressFlux = addressRepository.saveAll(addressList);
            Flux<Subject> subjectFlux = subjectRepository.saveAll(subjectList);
        });
        return studentMono;
    }
    @Override
    public Flux<StudentResponsePayload> getAllStudents() {
       return studentRepository.findAll().flatMap(student -> {
             Flux<Address> addressFlux = addressRepository.findByStudentId(student.getId()).switchIfEmpty(Flux.just(new Address()));
             Flux<Subject> subjectFlux = subjectRepository.findByStudentId(student.getId()).switchIfEmpty(Flux.just(new Subject()));
           StudentResponsePayload studentPayload = new StudentResponsePayload();
             studentPayload.setId(student.getId());
             studentPayload.setAge(student.getAge());
             studentPayload.setPhoneNumbers(student.getPhoneNumbers());
             studentPayload.setFirstName(student.getFirstName());
             studentPayload.setLastName(student.getLastName());
             studentPayload.setAddresses(addressFlux.collectList().block());
             studentPayload.setSubjects(subjectFlux.collectList().block());
             Flux<StudentResponsePayload> studentPayloadFlux = Flux.just(studentPayload);
             return studentPayloadFlux;
         });
       // return studentFlux;
    }

    public Flux<String> concat() {
        Flux<String> names1 = Flux.just("Hi ", " Hello ", "how ");
        Flux<String> names2 = Flux.just("are ", " you ", " Doing");
        Flux<String> names = Flux.concat(names1, names2).log();
        return names;
    }

    public Flux<String> merge() {
        Flux<String> names1 = Flux.just("Hi ", " Hello ", "how ");
        Flux<String> names2 = Flux.just("are ", " you ", " Doing");
        Flux<String> names = Flux.merge(names1, names2).log();
        return names;
    }

    public Flux<Integer> combineWithZip(){

        Flux<Integer> name1 = Flux.just(1, 2, 3);
        Flux<Integer> name2 = Flux.just(4,5,6);
        Flux<Integer> name3 = Flux.zip(name1,name2,(n1, n2)->{
            return n1*n2;
        });
        return name3;
    }
    public Mono<String> combineWithZipChara() {

        Mono<String> name1 = Mono.just("Hi");
        Mono<String> name2 = Mono.just("are");
        return Mono.just("sample");

    }

}
