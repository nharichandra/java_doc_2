This is the example of traditional kafka producer consumer application with spring boot
Here 2 applications. 1) kafka-producer application 2) kafka-consumer application
Producer application is responsible to publish the message in topic
Consumer application is responsible to consume the message through topic which is published by publisher application 
