package com.example.cicd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CicdTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CicdTestingApplication.class, args);
	}

}
