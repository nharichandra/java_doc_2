package com.abs.userservice.enums;

public class UserDesignationEnumList {
}
