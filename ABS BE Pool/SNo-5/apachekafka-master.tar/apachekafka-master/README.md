The below information all about implementing kafka in core applications using Java.

1. Implemented Producer component to publish message to the Kafka cluster/ broker
2. Implemented Consumer component to consume / subsribe messager from kafka server.
3. Implemented Producer by specifying key to each message to store in specific partition.
4. By default kafka Producer is asynchronous,But We can customize Producer as synchronous and implemented the same.

NOTE: You can run as java application as every component having main method.

NOTES: 

1. We can integate kafka in any application like  standalone , Web application , streaming application .
2. We can CLI to publish and subscribe message using commnad prompt without need to implement any application.
3. We have documented everythig and those are available in common location . 
