package com.nisum.Webflux.client;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.nisum.Webflux.model.Student;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class StudentClient {

	WebClient client = WebClient.create("http://localhost:8080");

	public Flux<Student> getAllStudents() {
		return client.get().uri("/students/getAll").accept(MediaType.APPLICATION_JSON).retrieve()
				.bodyToFlux(Student.class);
	}

	public Mono<Student> getStudent(Long studentId) {
		WebClient client = WebClient.create("http://localhost:8080");

		Mono<Student> result = client.get().uri("/student/{id}", studentId).accept(MediaType.APPLICATION_JSON)
				.retrieve().bodyToMono(Student.class);
		return result;
	}
	

}
