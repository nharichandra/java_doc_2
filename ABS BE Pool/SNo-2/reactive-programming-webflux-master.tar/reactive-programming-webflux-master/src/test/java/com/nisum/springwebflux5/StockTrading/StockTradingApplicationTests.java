package com.nisum.springwebflux5.StockTrading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockTradingApplicationTests {

	@Test
	void contextLoads() {
	}

}
