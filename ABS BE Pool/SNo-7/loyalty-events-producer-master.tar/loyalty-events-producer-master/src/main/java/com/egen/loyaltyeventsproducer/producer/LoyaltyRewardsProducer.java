package com.egen.loyaltyeventsproducer.producer;

import com.egen.loyaltyeventsproducer.model.LoyaltyRewards;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Flux;
import reactor.kafka.sender.KafkaSender;
import reactor.kafka.sender.SenderRecord;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class LoyaltyRewardsProducer {

    private static final Logger log = LoggerFactory.getLogger(LoyaltyRewardsProducer.class.getName());

    public LoyaltyRewards generateLoyaltyRewards(){
        List<String> loyaltyList = Arrays.asList("loyalty001", "loyalty002", "loyalty003");
        double total = ThreadLocalRandom.current().nextDouble(20, 100);
        return new LoyaltyRewards(UUID.randomUUID().toString(), loyaltyList.get((int) (Math.random()*3)), total, new Date());
    }

    public void generateMessages(KafkaSender<String, JsonNode> sender, String topic, int count) {

        ObjectMapper objectMapper = new ObjectMapper();
        sender.<Integer>send(Flux.range(1, count)
                .map(i -> {
                    JsonNode jsonValue = null;
                    try {

                        String value = objectMapper.writeValueAsString(generateLoyaltyRewards());
                        jsonValue = objectMapper.readTree(value);

                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    log.info("Message: {}, sent successfully", jsonValue);
                    return SenderRecord.create(new ProducerRecord<>(topic, "Key_" + UUID.randomUUID(), jsonValue), i);
                }))
                .doOnError(e -> log.error("Send failed", e))
                .subscribe(r -> {
                    RecordMetadata metadata = r.recordMetadata();
                    log.debug("Partition: {} -> Offset: {}", metadata.partition(), metadata.offset());
                });
    }
}
