package com.nisum.poc.Webflux.repository;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Subject;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface SubjectRepository extends ReactiveMongoRepository<Subject,Long> {
    Flux<Subject> findByStudentId(Long subjectId);

}
