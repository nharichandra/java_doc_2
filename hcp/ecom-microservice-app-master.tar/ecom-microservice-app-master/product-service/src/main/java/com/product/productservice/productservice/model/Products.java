package com.product.productservice.productservice.model;

import java.util.List;

public class Products {
    private List<Product> productList;

    public Products(List<Product> productList) {
        this.productList = productList;
    }

    public Products() {
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }
}
