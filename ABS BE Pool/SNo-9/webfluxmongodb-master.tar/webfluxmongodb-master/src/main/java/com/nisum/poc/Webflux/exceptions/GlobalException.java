package com.nisum.poc.Webflux.exceptions;


public class GlobalException extends RuntimeException{
        public GlobalException( String message) {
        super(message);

    }
}
