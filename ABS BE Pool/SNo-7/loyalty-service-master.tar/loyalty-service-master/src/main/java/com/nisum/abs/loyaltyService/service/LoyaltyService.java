package com.nisum.abs.loyaltyService.service;

import com.nisum.abs.loyaltyService.dto.LoyaltyDto;
import com.nisum.abs.loyaltyService.repository.LoyaltyRepository;
import com.nisum.abs.loyaltyService.util.EntityToDtoConversionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class LoyaltyService {


    @Autowired
    private LoyaltyRepository loyaltyRepository;

    public Flux<LoyaltyDto> getAll()
    {
        return this.loyaltyRepository.findAll()
                .map(EntityToDtoConversionUtil::convertEntityToDto);
    }

    public Mono<LoyaltyDto> getLoyaltyById(String loyaltyId){
        return this.loyaltyRepository.findById(loyaltyId)
                .map(EntityToDtoConversionUtil::convertEntityToDto);
    }

    public Mono<LoyaltyDto> saveLoyalty(Mono<LoyaltyDto> loyaltyDto){
        return loyaltyDto.map(EntityToDtoConversionUtil::convertDtoToEntity)
                .flatMap(this.loyaltyRepository::insert)
                .map(EntityToDtoConversionUtil::convertEntityToDto);
    }

    public Mono<LoyaltyDto> updateLoyalty(String loyaltyId, Mono<LoyaltyDto> loyaltyDto){
        return this.loyaltyRepository.findById(loyaltyId)
                .flatMap(l->loyaltyDto.map(EntityToDtoConversionUtil::convertDtoToEntity)
                        .doOnNext(e->e.setLoyaltyId(loyaltyId)))
                        .flatMap(this.loyaltyRepository::save)
                        .map(EntityToDtoConversionUtil::convertEntityToDto);

    }

    public Mono<Void> deleteLoyalty(String loyaltyId){
       return this.loyaltyRepository.deleteById(loyaltyId);
    }
}
