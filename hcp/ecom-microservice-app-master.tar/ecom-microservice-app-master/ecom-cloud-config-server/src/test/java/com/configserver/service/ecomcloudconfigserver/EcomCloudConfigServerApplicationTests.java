package com.configserver.service.ecomcloudconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomCloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
