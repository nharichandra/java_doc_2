This project mainly focused on Spring security and springboot, I include java8 features, JPA, and MySQL Database.

Note : I added Database dump file in resource folder for DB access.

**Below are the URL's for access**

Not required any credential for below URL's

* http://localhost:8080/
* http://localhost:8080/book/welcome
* http://localhost:8080/book/info


We can access below URL's using required credentials and based on the specific roles:

*  http://localhost:8080/user
   
username : arjuna

password : arjuna



*  http://localhost:8080/admin
   
username : drona

password : drona


