package com.abs.userservice.exception;

public class Exception {
}
