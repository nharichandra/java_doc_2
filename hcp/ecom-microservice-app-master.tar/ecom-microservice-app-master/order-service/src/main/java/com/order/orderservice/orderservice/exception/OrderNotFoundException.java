package com.order.orderservice.orderservice.exception;

import org.springframework.stereotype.Component;

@Component
public class OrderNotFoundException extends RuntimeException{
    public OrderNotFoundException() {
    }

    public OrderNotFoundException(String message) {
        super(message);
    }
}
