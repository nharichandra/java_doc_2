package com.nisum.poc.Webflux.model;


import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Subject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.aggregation.ArrayOperators;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentPayload {
    private Long id;
    private String firstName;
    private String lastName;
    private Integer age;
    private List<String> phoneNumbers;
    private List<AddressPayload> addresses;
    private List<SubjectPayload> subjects;
}
