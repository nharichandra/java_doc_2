package com.nisum.kafkaexample.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.nisum.kafkaexample.entity.Product;

public interface ProductRepository extends MongoRepository<Product, Integer> {
}
