package com.nisum.livescorestream.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.livescorestream.entity.LiveScore;
import com.nisum.livescorestream.service.LiveScoreService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/livescore")
public class LiveScoreController {

	@Autowired
	private LiveScoreService liveScoreService;
	

	@PostMapping
	public Mono<LiveScore> saveProduct(@RequestBody Mono<LiveScore> liveScore) {
		return liveScoreService.saveLiveScore(liveScore);
	}
	
	@GetMapping(value = "", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	@CrossOrigin(origins = "*")
	@ResponseBody
	Flux<LiveScore> findPets() {
		return liveScoreService.getLiveFeed();

	}
	
}
