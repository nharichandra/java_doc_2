package com.sample.javawithkafka;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class ProducerDemo {
    private static final Logger logger = LoggerFactory.getLogger(ProducerDemo.class.getName());
    public static void main(String[] args) {
        KafkaProducer<String, String> producer = null;
        try
        {
            // Steps - create producer configs, create producer, send data / messages
            String bootstrapServers = "127.0.0.1:9092";
            // Initialize Producer configuration mandatory properties
            Properties properties = new Properties();
            properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
            properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
            //The below acks property is optional to use but recommended in real time
            //properties.setProperty(ProducerConfig.ACKS_CONFIG,"all");

            producer = new KafkaProducer<String, String>(properties);

            ProducerRecord<String, String> record = new ProducerRecord<>("demo_topic_A","test message3:16PM");

            // Publishing messages to broker using Fire&Forget Approach
            producer.send(record);

        }
        catch (Exception e)
        {
            logger.error("Exception occurred:"+e);
        }
        finally {
            producer.flush();
            producer.close();
        }

    }
}