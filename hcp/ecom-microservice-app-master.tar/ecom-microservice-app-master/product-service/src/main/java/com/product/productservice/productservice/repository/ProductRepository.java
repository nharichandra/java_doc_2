package com.product.productservice.productservice.repository;

import com.product.productservice.productservice.model.Product;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
@RefreshScope
public interface ProductRepository extends MongoRepository<Product, String> {
}
