package com.nisum.employee.exceptions;

/**
 * 
 * @author Rjosula
 *
 */
public class ResourceNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructor of ResourceNotFoundException.
     * @param msg
     */
    public ResourceNotFoundException(String msg) {
      super(msg);
    }
}
