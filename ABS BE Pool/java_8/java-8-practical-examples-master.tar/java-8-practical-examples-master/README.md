# Java 8 Practical Examples

Sort the hashMap Keys in Desc Order?

Sort the hashMap Keys in Asc Order?

Sort the hashMap Values in Desc Order?

Sort the hashMap Values in Asc Order?

Sort the Employee by sal in desc?

Get the Employee whose salary is maximum?

Get The Maximum salary of Employee in each department ?

Duplicate Number From a List?

Occurance of a Character from a String?

Occurance of a number from a List

From the list of employees, get the first employee from the list and return his fullName.
where fullName = firstname + lastname.

Given a list of employees. Can you create a map with the count of employees each department has ?
with key as department name and count of employees as value.

 Consider a list of employees, sort the employees by their firstName and return the sorted list of employees.
 
Consider a list of employees, return the employee whose empId is highest.

Consider a list of employees, concat the fullName of all the employees with pipe (|) and return the concatenated string.
where fullName = firstname + lastname.
ex: niranjankumar|viswaraj

Consider a list of 10 employees, get the 8th employee and print his full name and department name.

 Consider a list of employees and get the count of employees based on the Gender 
 
 Get all the employees in ascending order based on the salary.