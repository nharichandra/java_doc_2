package com.nisum.poc.Webflux.service.impl;

import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.repository.SubjectRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static org.mockito.Mockito.*;

class SubjectsServiceImplTest {
    @Mock
    SubjectRepository subjectRepository;
    @Mock
    Logger log;
    @InjectMocks
    SubjectsServiceImpl subjectsServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateSuject() {
        Mono<Subject> result = subjectsServiceImpl.createSuject(new Subject(Long.valueOf(1), "subjectName", Long.valueOf(1)));
        Assertions.assertEquals(null, result);
    }

    @Test
    void testGetAllSubjects() {
        Flux<Subject> result = subjectsServiceImpl.getAllSubjects();
        Assertions.assertEquals(null, result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme