1. spring-reactive-mongodb - This poc contains CRUD operations with Spring Webflux and Reactive MongoDB along with Exception Handling. And Functional Endpoints with Router and Handler Mechanism.
2. spring-webflux-practise and live-score-stream - These apps contain Webflux code with Mono, flux, text/event-stream and tailable cursor(mongo reactive).
3. webclient-example - This poc contains usecase of webclient to intergrate with reactive rest api and consumer the reponse.
3. kafka-example - This poc contains Kafka Consumer and producer with manual offset commit and scheduled consuming use cases .
4. mongodb-query-practise - This file contains MongoDB querying techniques practice examples