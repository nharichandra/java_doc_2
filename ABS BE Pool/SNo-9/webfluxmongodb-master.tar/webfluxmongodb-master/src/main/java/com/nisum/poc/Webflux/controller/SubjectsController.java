package com.nisum.poc.Webflux.controller;

import com.nisum.poc.Webflux.entity.Address;
import com.nisum.poc.Webflux.entity.Subject;
import com.nisum.poc.Webflux.service.ISubjectsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class SubjectsController {

    @Autowired
    ISubjectsService subjectsService;

    @PostMapping("/savesubject")
    public Mono<Subject> creatSubject(@RequestBody Subject subject){
        return subjectsService.createSuject(subject);

    }

    @GetMapping("/allsubjects")
    public Flux<Subject> getAllSubjects(){
        return subjectsService.getAllSubjects();

    }

}
