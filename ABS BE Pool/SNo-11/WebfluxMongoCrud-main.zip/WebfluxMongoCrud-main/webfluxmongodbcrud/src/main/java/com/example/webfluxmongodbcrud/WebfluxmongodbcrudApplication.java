package com.example.webfluxmongodbcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class WebfluxmongodbcrudApplication {

    public static void main(String[] args) {

        SpringApplication.run(WebfluxmongodbcrudApplication.class, args);
    }

}
