package com.egen.loyaltyeventsproducer.model;

import java.util.Date;

public class LoyaltyRewards {

    private String certId;
    private String loyaltyId;
    private double rewardPoints;
    private Date createdDate;

    public LoyaltyRewards() {
    }

    public LoyaltyRewards(String certId, String loyaltyId, double rewardPoints, Date createdDate) {
        this.certId = certId;
        this.loyaltyId = loyaltyId;
        this.rewardPoints = rewardPoints;
        this.createdDate = createdDate;
    }


    public String getCertId() {
        return certId;
    }

    public void setCertId(String certId) {
        this.certId = certId;
    }

    public String getLoyaltyId() {
        return loyaltyId;
    }

    public void setLoyaltyId(String loyaltyId) {
        this.loyaltyId = loyaltyId;
    }

    public double getRewardPoints() {
        return rewardPoints;
    }

    public void setRewardPoints(double rewardPoints) {
        this.rewardPoints = rewardPoints;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
}