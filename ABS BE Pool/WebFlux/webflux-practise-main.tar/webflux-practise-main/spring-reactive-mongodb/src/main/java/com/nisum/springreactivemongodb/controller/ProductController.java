package com.nisum.springreactivemongodb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nisum.springreactivemongodb.dto.ProductDto;
import com.nisum.springreactivemongodb.exception.CustomException;
import com.nisum.springreactivemongodb.service.ProductService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	private ProductService productService;

//	@Autowired
//	private ProductRepository productRepository;

	@GetMapping(produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<ProductDto> getProducts() {
		return productService.getProducts();
	}

	@GetMapping(value = "/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Mono<ProductDto> getOneProduct(@PathVariable String id) {
		Mono<ProductDto> result =  productService.getOneProduct(id);
		return result.switchIfEmpty(Mono.error(new CustomException("Object not found")));
		//return result.switchIfEmpty(Mono.justOrEmpty(null).concatWith(Mono.error(new Exception("not found"))));
	}

	@GetMapping(value = "/product-range", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<ProductDto> getProductBetweenRange(@RequestParam double min, @RequestParam double max) {
		return productService.getProductsInRange(min, max);
	}

	@PostMapping(produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Mono<ProductDto> saveProduct(@RequestBody Mono<ProductDto> productDtoMono) {
		return productService.saveProduct(productDtoMono);
	}

	@PutMapping(value = "/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Mono<ProductDto> updateProduct(@RequestBody Mono<ProductDto> productDtoMono, @PathVariable String id) {
		return productService.updateProduct(productDtoMono, id);
	}

	@DeleteMapping(value = "/delete/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Mono<Void> deleteProduct(@PathVariable String id) {
		return productService.deleteProduct(id);
	}

//	@GetMapping(value = "/live", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
//	@CrossOrigin(origins = "*")
//	@ResponseBody
//	Flux<Product> findPets() {
//		return productRepository.findWithTailableCursorBy().delayElements(Duration.ofMillis(2500));
//
//	}

}
