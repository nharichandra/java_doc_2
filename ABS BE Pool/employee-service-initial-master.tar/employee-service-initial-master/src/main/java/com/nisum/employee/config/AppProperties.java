/**
 * 
 */
package com.nisum.employee.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Rjosula
 *
 */
@Configuration
@ConfigurationProperties (prefix = "spring.data.mongodb")
@Setter
@Getter
public class AppProperties {

    private String uri;
}
