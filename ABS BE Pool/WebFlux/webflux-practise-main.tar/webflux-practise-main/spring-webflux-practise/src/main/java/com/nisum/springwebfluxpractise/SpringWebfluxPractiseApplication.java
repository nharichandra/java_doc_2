package com.nisum.springwebfluxpractise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebfluxPractiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebfluxPractiseApplication.class, args);
	}

}
