package com.nisum.employee.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nisum.employee.dto.Employee;
import com.nisum.employee.entity.EmployeeDocument;
import com.nisum.employee.exceptions.ResourceNotFoundException;
import com.nisum.employee.repository.EmployeeQueryRepositoryImpl;
import com.nisum.employee.repository.EmployeeRepository;
import com.nisum.employee.repository.SequenceGenService;
import com.nisum.employee.util.EmpUtility;

/**
 * Employee implementation for methods / operations.
 * 
 * @author Rjosula
 *
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository emplRepository;
    
    @Autowired
    private SequenceGenService employeeSeqGenService;
    
    @Autowired
    private EmployeeQueryRepositoryImpl queryRepository;
    
    /**
     * Override documentation.
     */
    @Override
    public Optional<Employee> createEmployee(Employee employee) {
        long empId = employeeSeqGenService.getNextValue(EmployeeDocument.SEQUENCE_NAME);
        employee.setEmployeeId(empId);
        EmployeeDocument doc = EmployeeMapperService.MAPPER.employeeDocumentToDto(employee);
        doc.setCreatedDate(LocalDateTime.now());
        doc.setModifiedDate(LocalDateTime.now());
        return Optional.ofNullable(EmployeeMapperService.MAPPER
                .employeeDtoToDocument(emplRepository.save(doc)));
    }
    
    /**
     * @param employee employee dto input
     * @return employee dto
     */
    @Override
    public Employee updateEmployee(Employee employee) {
        
        EmployeeDocument employeeDocument = emplRepository
                .findById(employee.getEmployeeId()).get();
        employeeDocument.setEmployeeSalary(employee.getEmployeeSalary());
        employeeDocument.setEmployeeAddress(employee.getEmployeeAddress());
        return queryRepository.updateEmployee(employeeDocument);
    }

    /**
     * Override documentation.
     */
    @Override
    public Employee fetchEmployee(Long employeeId) {
        Optional<EmployeeDocument> empDoc = emplRepository.findById(employeeId);
        return EmployeeMapperService.MAPPER.employeeDtoToDocument(empDoc
                .orElseThrow(() ->
                new ResourceNotFoundException("Employee does not exist")));
    }
    
    /**
     * Override documentation.
     */
    @Override
    public List<Employee> fetchEmployeesByDepartment(String departmentId) {
        
        return queryRepository.getAllEmployeesByDept(departmentId);
    }

    /**
     * Override documentation.
     */
    @Override
    public List<Employee> fetchAllEmployees() {
        List<EmployeeDocument> emplDocs = (List<EmployeeDocument>) emplRepository.findAll();
        return EmpUtility.provideEmployeeDto(emplDocs);
    }

    /**
     * Override documentation.
     */
    @Override
    public List<Employee> fetchAllEmployeesDoesNotUpdatedAddresses() {
        return queryRepository.getEmployeesWhoDidNotUpdatedAddresses();
    }

    /**
     * Override documentation.
     */
    @Override
    public Map<String, List<Employee>> fetchEmployeeCollectionGroupByDepartment() {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Override documentation.
     */
    @Override
    public Optional<List<Employee>> fetchAllEmployeeForGivenIds(List<String> emplIds) {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Override documentation.
     */
    @Override
    public Optional<List<Employee>> fetch2MaxSalariedEmployees() {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Override documentation.
     */
    @Override
    public Optional<List<Employee>> fetchAllEmployeesOrderByAscSalaries() {
        // TODO Auto-generated method stub
        return null;
    }


}
