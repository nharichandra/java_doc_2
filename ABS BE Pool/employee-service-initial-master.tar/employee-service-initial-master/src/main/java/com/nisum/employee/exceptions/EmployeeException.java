package com.nisum.employee.exceptions;

public class EmployeeException extends RuntimeException {

    public EmployeeException(String message) {
        super(message);
    }
}
