package com.order.orderservice.orderservice.service;

import com.order.orderservice.orderservice.model.Order;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public interface IOrderService {

    public Order saveOrder(Order order);
    public Order getOrderById(String orderId);
    public List<Order> getAllOrders();
    public Order updateOrder(Order order, String orderId);
    public List<Order> getOrdersByDate(LocalDateTime dateTime);

}
