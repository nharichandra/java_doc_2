package com.nisum.springreactivemongodb.router;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.WebProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.nisum.springreactivemongodb.handler.ProductHandler;

@Configuration
public class RouterConfig {

    @Autowired
    private ProductHandler producthandler;

//    @Autowired
//    private CustomerStreamHandler streamHandler;

    @Bean
    public WebProperties.Resources resources(){
        return new WebProperties.Resources();
    }
    
    @Bean
    public RouterFunction<ServerResponse> routerFunction(){
        return RouterFunctions.route()
                .GET("/router/products",producthandler::getProducts)
                .GET("/router/products/{id}",producthandler::getOneProduct)
                .GET("/router/products-range",producthandler::getProductInRange)
                .POST("/router/products",producthandler::saveProduct)
                .PUT("/router/products/{id}",producthandler::updateProduct)
                .DELETE("/router/products/delete/{id}", producthandler::deleteProduct)
                .build();

    }
}